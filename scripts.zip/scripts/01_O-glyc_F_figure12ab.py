import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import sys, collections, pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
U=DATA_
CFG={"A":dict(tvs="NetOGlyc_F_RSVA.tvs.txt",fa="F_RSVA_proteins_with_ref.fasta",refpat="KY654518",refid="KY654518.1_RSVA",ref_lab="Reference KY654518.1",sub="RSV-A",fig="12a",top=.30,extra=[99,105,276,522,523]),
     "B":dict(tvs="NetOGlyc_F_RSVB.tvs.txt",fa="F_RSVB_proteins_with_ref.fasta",refpat="OP975389",refid="OP975389_RSVB",ref_lab="Reference OP975389",sub="RSV-B",fig="12b",top=.30,extra=[100,182,190,211,380,389])}
SUB=sys.argv[1]; c=CFG[SUB]
rows=[l.rstrip("\n").split("\t") for l in open(U+c["tvs"]) if not l.startswith("#")]
rows=[r for r in rows if len(r)>=6 and r[2]=="CARBOHYD"]
d=pd.DataFrame({"n":[r[0] for r in rows],"p":[int(r[3]) for r in rows],"s":[float(r[5]) for r in rows]})
isref=d.n.str.contains(c["refpat"]); nb=d[~isref].n.nunique()
ref=d[isref].set_index("p").s; bd=d[~isref].groupby("p").s.agg(mean="mean",n="count")
s={};k=None
for l in open(U+c["fa"]):
    l=l.strip()
    if l.startswith(">"): k=l[1:].split("|")[0];s[k]=""
    elif k: s[k]+=l
s={k:v.rstrip("*") for k,v in s.items()}; R=s[c["refid"]]; B=[v for k,v in s.items() if k!=c["refid"]]
rec=[]
for i,r in enumerate(R):
    p=i+1; col=collections.Counter(v[i] for v in B); nst=sum(x for a,x in col.items() if a in "ST")
    if r in "ST" or nst:
        top=col.most_common(1)[0][0]
        rec.append(dict(pos=p,refres=r,n_st=nst,bd_mean=bd["mean"].get(p,np.nan),ref_s=ref.get(p,np.nan),chg=(f"{r}{p}{top}" if top!=r else f"{r}{p}")))
T=pd.DataFrame(rec); T["freq"]=T.n_st/nb
T["status"]=np.where((T.refres.isin(list("ST")))&(T.n_st>0),"shared",np.where(T.n_st==0,"lost","gained"))
T.assign(score_top=T[["bd_mean","ref_s"]].max(axis=1)).round(3).to_csv(f"{OUT_}tmp_{sys.argv[1]}.csv",index=False)
ag=[("Ø",61,69,"#E41A1C"),("V",160,180,"#377EB8"),("Ø",196,212,"#E41A1C"),("II",254,277,"#4DAF4A"),("I",382,396,"#984EA3"),("IV",422,438,"#FF7F00")]
fig,(ax,bx)=plt.subplots(2,1,figsize=(10,5.6),dpi=300,sharex=True,gridspec_kw=dict(height_ratios=[6,.7],hspace=.06))
for nm,a,b,col in ag: ax.axvspan(a,b,color=col,alpha=.12,lw=0); bx.barh(0,b-a+1,left=a,height=.8,color=col,alpha=.85); bx.text((a+b)/2,.75,nm,ha="center",fontsize=8,fontweight="bold",color=col)
MAIN=len(sys.argv)>2
T["top"]=T[["bd_mean","ref_s"]].max(axis=1)
T["keep"]=(T.top>=.20)|(T.top>=c["top"])|T.pos.isin(c["extra"])|(T.status=="lost")
TT=T
if MAIN: T=T[T.keep].copy()
CC={"shared":"#2C7FB8","gained":"#D95F02"}
for st,col in CC.items():
    q=T[(T.status==st)&T.bd_mean.notna()]
    ax.vlines(q.pos,0,q.bd_mean,color=col,lw=1.2,alpha=.9); ax.scatter(q.pos,q.bd_mean,s=14+50*q.freq,color=col,zorder=3,edgecolors="none")
q=T[T.ref_s.notna()&(T.n_st>0)]; ax.scatter(q.pos,q.ref_s,marker="D",s=26,facecolors="none",edgecolors="#222",lw=.8,zorder=4)
L=T[T.status=="lost"]; ax.scatter(L.pos,[0.012]*len(L),marker="^",s=48,facecolors="white",edgecolors="#444",lw=1.2,zorder=5)
T["top"]=T[["bd_mean","ref_s"]].max(axis=1)
lab=T[(T.top>=c["top"])|T.pos.isin(c["extra"])].copy(); print("labels:",lab.pos.tolist())
OFF={("B",100):(-8,18),("B",118):(-26,6),("B",128):(-20,22),("B",130):(40,-22),("B",182):(-30,12),("B",186):(24,22),("B",244):(0,14),("B",380):(-20,32),("B",190):(-30,24),("B",211):(30,24),("B",389):(-6,40),
("A",99):(-22,14),("A",103):(-55,95),("A",105):(-45,55),("A",182):(-24,10),("A",186):(34,-24),("A",238):(-40,14),("A",244):(-26,6),("A",248):(26,6),("A",245):(30,-6),("A",276):(30,14),("A",369):(0,14),("A",522):(0,14),("A",523):(24,10)}
Tx=[]
for _,r in lab.iterrows():
    t=f"{r.chg}" if r.status!="shared" or r.pos in c["extra"] else f"{r.refres}{r.pos}"
    if r.n_st not in (0,nb): t+=f" ({int(r.n_st)}/{nb})"
    if r.status=="lost": t+=" lost"
    y0=(0.012 if r.status=="lost" else max(r.top,.03))
    dx,dy=OFF.get((SUB,int(r.pos)),(0,14 if r.status!="lost" else 26))
    ax.annotate(t,(r.pos,y0),xytext=(dx,dy),textcoords="offset points",fontsize=8.2,fontweight="bold",ha="center",va="bottom",arrowprops=dict(arrowstyle="-",lw=.5,color="grey",shrinkA=0,shrinkB=3),bbox=dict(fc="white",ec="none",alpha=.85,pad=.8),zorder=8)
ax.axhline(.5,ls="--",color="grey",lw=1); ax.text(598,.512,"NetOGlyc threshold (0.5)",ha="right",fontsize=8.5,color="grey")
ax.set_ylim(0,.62);ax.set_ylabel("NetOGlyc 4.0 score");ax.set_title(f"O-glycosylation sites of the {c['sub']} F protein",loc="left",fontweight="bold",pad=8)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
bx.set_ylim(-.6,1.2);bx.set_yticks([]);bx.set_xlim(0,600);bx.set_xlabel(f"Amino acid position ({c['sub']} F protein)")
for sp in ("top","right","left"): bx.spines[sp].set_visible(False)
h=[Line2D([],[],marker="o",ls="",color="#2C7FB8"),Line2D([],[],marker="o",ls="",color="#D95F02"),Line2D([],[],marker="D",ls="",mfc="none",mec="#222"),Line2D([],[],marker="^",ls="",mfc="white",mec="#444",ms=8)]
fig.legend(h,["Ser/Thr conserved","Ser/Thr gained in BD","Reference "+c["ref_lab"].split()[-1],"Ser/Thr lost in BD"],loc="lower center",ncol=4,frameon=False,fontsize=8.5)
fig.subplots_adjust(bottom=.2,top=.92,left=.07,right=.98)
sfx="main" if MAIN else "supplementary"
if MAIN: fig.text(.07,.075,"Only sites with NetOGlyc score \u2265 0.20 or of interest are drawn; all sites are shown in the Supplementary Figure.",fontsize=7.5,color="grey")
plt.savefig(f"{OUT_}Figure{c['fig']}_{sfx}.png");plt.savefig(f"{OUT_}Figure{c['fig']}_{sfx}.pdf")
