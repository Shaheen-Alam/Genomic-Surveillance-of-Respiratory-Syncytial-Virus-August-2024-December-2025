"""Figures 13a/13b (main draft): simplified O-glycosylation profiles of the RSV G protein
labelling only the sites discussed in the text; the full versions are the supplementary figures.
Run after 03 and 04."""
import os, sys, shutil, pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import OUT_
OUT=OUT_  # run after scripts 03 and 04
CFG={"A":dict(csv="Supplementary_Table_Fig13a_O-glyc_RSVA_G.csv",pos="Position_BD_numbering",sub="RSV-A",n=43,xmax=335,
              xl="Amino acid position (RSV-A G protein, Bangladeshi isolate numbering)",dom_end=320,fig="13a"),
     "B":dict(csv="Supplementary_Table_Fig13b_O-glyc_RSVB_G.csv",pos="Position",sub="RSV-B",n=6,xmax=318,
              xl="Amino acid position (RSV-B G protein)",dom_end=309,fig="13b")}
C={"Shared with reference":"#2C7FB8","BD-only":"#D95F02","ON1 duplicated segment":"#7B68AE"}
dom=[("TM",38,66,"#bdbdbd"),("MLR-I",67,163,"#1B9E77"),("CCD",164,181,"#D62728"),("CX3C",182,186,"#E6B800"),("HBD",187,198,"#1F77B4")]
for k,c in CFG.items():
    T=pd.read_csv(OUT+c["csv"]); P=c["pos"]; nb=c["n"]
    ref_only=T.Status.str.startswith("Reference-only")
    dup=T.Status.eq("ON1 duplicated segment")
    ccd=T[P].between(164,190)
    key=(~dup)&(ref_only|((T.Status=="BD-only")&(T.BD_frequency>=.3))|((T.BD_frequency>=.3)&(T.BD_frequency<.7))|ccd)
    K=T[key].copy()
    fig,(ax,rg,bx)=plt.subplots(3,1,figsize=(11,5.4),dpi=300,sharex=True,gridspec_kw=dict(height_ratios=[6,.55,.9],hspace=.08))
    if k=="A" and dup.any():
        ax.axvspan(261,284,color="#7B68AE",alpha=.10,lw=0)
        nd=int(dup.sum()); lo=T[dup].BD_frequency.min()
        ax.text(272.5,.5,f"ON1 24-aa duplication\n{nd} predicted sites\n({lo*100:.0f}–100% of isolates)",ha="center",va="center",fontsize=8.5,color="#5b4a8f")
    for st in ("Shared with reference","BD-only"):
        q=K[(K.Status==st)&(K.BD_isolates_positive>0)]
        ax.vlines(q[P],0,q.BD_frequency,color=C[st],lw=1.6); ax.scatter(q[P],q.BD_frequency,s=40+60*q.BD_frequency,color=C[st],zorder=3,edgecolors="none")
    q=K[K.Status.str.startswith("Reference-only")]
    ax.scatter(q[P],[0.02]*len(q),marker="^",s=60,facecolors="white",edgecolors="#444",lw=1.2,zorder=4)
    Tx=[]
    cc=K[K[P].between(164,190)&(K.BD_frequency==1)]
    if len(cc):
        ax.text(cc[P].mean(),1.045,"CCD / CX3C region\n"+", ".join(str(int(v)) for v in cc[P]),ha="center",va="bottom",fontsize=8.5,fontweight="bold",color="#222")
    for r in K.itertuples():
        pos=getattr(r,P); n=r.BD_isolates_positive
        if 164<=pos<=190 and r.BD_frequency==1: continue
        t=f"{pos}" + ("" if n==nb else f" ({n}/{nb})")
        Tx.append(ax.text(pos,max(r.BD_frequency,.04)+.025,t,fontsize=8.5,fontweight="bold",color="#222",ha="center"))
    adjust_text(Tx,ax=ax,arrowprops=dict(arrowstyle="-",lw=.4,color="grey"),expand=(1.3,1.7))
    ax.set_ylim(0,1.22);ax.set_yticks([0,.25,.5,.75,1]);ax.set_yticklabels(["0%","25%","50%","75%","100%"]);ax.set_ylabel("Isolates with predicted site (%)")
    ax.set_title(f"O-glycosylation sites of the {c['sub']} G protein",loc="left",fontweight="bold",pad=8)
    for sp in ("top","right"): ax.spines[sp].set_visible(False)
    # rug: every predicted site
    allp=T[T.BD_isolates_positive>0][P]
    rg.vlines(allp,0,1,color="#555",lw=.7); rg.set_ylim(0,1); rg.set_yticks([]); rg.set_ylabel("all sites",rotation=0,ha="right",va="center",fontsize=8)
    for sp in ("top","right","left","bottom"): rg.spines[sp].set_visible(False)
    rg.tick_params(axis="x",length=0,labelbottom=False)
    for nm,a,b,col in dom+[("MLR-II",199,c["dom_end"],"#B39DDB")]:
        bx.barh(0,b-a+1,left=a,height=.8,color=col,alpha=.9); bx.text((a+b)/2,0,nm if b-a>10 else "",ha="center",va="center",fontsize=8,fontweight="bold",color="white" if nm in("MLR-I","CCD","HBD") else "#222")
    bx.text(184,.62,"CX3C",ha="center",fontsize=7.5,va="bottom")
    bx.set_ylim(-.6,.95);bx.set_yticks([]);bx.set_xlim(0,c["xmax"]);bx.set_xlabel(c["xl"])
    for sp in ("top","right","left"): bx.spines[sp].set_visible(False)
    h=[Line2D([],[],marker="o",ls="",color=C["Shared with reference"]),Line2D([],[],marker="o",ls="",color=C["BD-only"]),Line2D([],[],marker="^",ls="",mfc="white",mec="#444",ms=7)]
    lab=["Shared with reference","Bangladeshi isolates only","Reference site absent in all isolates"]
    fig.legend(h,lab,loc="lower center",ncol=3,frameon=False,fontsize=9)
    fig.text(.07,.06,"Selected sites shown (CCD/CX3C region, Bangladeshi-specific, variable and reference-only sites); all predicted\nsites are marked in the strip below the plot and listed in Supplementary Table S%s."%("38" if k=="A" else "39"),fontsize=7.5,color="grey")
    fig.subplots_adjust(bottom=.22,top=.92,left=.07,right=.98)
    plt.savefig(OUT+f"Figure{c['fig']}_main.png");plt.savefig(OUT+f"Figure{c['fig']}_main.pdf")
    shutil.copy(OUT+f"Figure{c['fig']}_simplified.png",OUT+f"Figure{c['fig']}_supplementary.png"); shutil.copy(OUT+f"Figure{c['fig']}_simplified.pdf",OUT+f"Figure{c['fig']}_supplementary.pdf"); shutil.copy(OUT+f"Figure{c['fig']}_simplified.svg",OUT+f"Figure{c['fig']}_supplementary.svg")
    print(k,"labelled",K[P].tolist())
