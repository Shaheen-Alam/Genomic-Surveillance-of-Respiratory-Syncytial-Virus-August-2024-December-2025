#!/usr/bin/env python3
"""Compare the sequenced RSV-positive specimens with all other RSV-positive specimens (Reviewer 1, comment 1).

Inputs (not shipped in this repository because they carry patient names; ask the study team):
  master  : Final_Method_RSV_Aug_2024_Dec_2025_with_hos_id.xlsx   (one row per enrolled episode)
  seq_csv : 59_Sequenced_RSV_metadata.csv                          (column idcode)
Output: a CSV with counts and p-values for all RSV-positive and for Ct <=25 only.
Tests: Fisher exact test (2x2) or Pearson chi-square with a Monte-Carlo permutation p-value (r x c, 100,000 permutations, seed 1).
"""
import sys, numpy as np, pandas as pd
from scipy.stats import fisher_exact, chi2_contingency
master, seq_csv, out = sys.argv[1:4]
d = pd.read_excel(master); s = pd.read_csv(seq_csv)
d['seq'] = d['idcode'].isin(s['idcode'])
d['Ct_RSV'] = pd.to_numeric(d['Ct_RSV'], errors='coerce')
pos = d[d['RSV_results'].astype(str).str.lower().eq('positive')].copy()
def agegrp(r):
    if pd.isna(r['age_yy']) and pd.isna(r['age_mm']): return 'Missing'
    m = (0 if pd.isna(r['age_yy']) else r['age_yy']) * 12 + (0 if pd.isna(r['age_mm']) else r['age_mm']); y = m / 12
    if m < 2: return '<2 months'
    if m < 6: return '2-5 months'
    if m < 12: return '6-11 months'
    if m < 24: return '12-23 months'
    if m < 60: return '24-59 months'
    if y < 18: return '5-17 years'
    if y < 40: return '18-39 years'
    if y < 60: return '40-59 years'
    return '>=60 years'
pos['agegrp'] = pos.apply(agegrp, axis=1)
rng = np.random.default_rng(1)
def mc_p(x, y, n=100000):
    x = pd.factorize(x)[0]; y = pd.factorize(y)[0]
    def stat(a, b):
        t = np.zeros((a.max() + 1, b.max() + 1)); np.add.at(t, (a, b), 1)
        e = t.sum(1)[:, None] * t.sum(0)[None, :] / t.sum()
        return ((t - e) ** 2 / e).sum()
    o = stat(x, y); c = 0
    for _ in range(n):
        c += stat(x, rng.permutation(y)) >= o - 1e-9
    return (c + 1) / (n + 1)
rows = []
for var in ['case_grp', 'sex', 'RSV_type', 'agegrp', 'hos_id']:
    for label, sub in [('all', pos), ('Ct<=25', pos[pos['seq'] | (pos['Ct_RSV'] <= 25)])]:  # Ct<=25 row: all sequenced vs unsequenced with Ct <=25
        # compare sequenced vs not sequenced
        tab = pd.crosstab(sub[var].fillna('Missing'), sub['seq'])
        p = fisher_exact(tab.values)[1] if tab.shape == (2, 2) else mc_p(sub[var].fillna('Missing'), sub['seq'])
        rows.append(dict(variable=var, comparison=label, p=round(p, 3), **{f'{k}': v for k, v in tab.to_dict().items()}))
pd.DataFrame(rows).to_csv(out, index=False)
print('RSV-positive', len(pos), '| sequenced found in master', int(pos['seq'].sum()), '| sequenced with Ct>25', int((pos['seq'] & (pos['Ct_RSV'] > 25)).sum()))
print(pd.DataFrame(rows)[['variable', 'comparison', 'p']].to_string(index=False))
