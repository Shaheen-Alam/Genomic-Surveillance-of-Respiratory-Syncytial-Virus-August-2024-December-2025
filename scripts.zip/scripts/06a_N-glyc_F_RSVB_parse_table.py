import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import re, pandas as pd, numpy as np, collections, pickle
txt=pdftext("NetNGlyc_F_RSVB.pdf").replace("\x0c","")
blocks=re.split(r"^Output for ",txt,flags=re.M)[1:]; seqs={};rec=[]
for b in blocks:
    m=re.search(r"^Name:\s+(\S+)\s+Length:\s+(\d+)",b,re.M); name=m.group(1)
    seqs[name]="".join(t[0] for t in (l.split() for l in b.split("\n")) if len(t)==2 and t[1].isdigit() and re.fullmatch(r"[A-Z\*]+",t[0]) and len(t[0])<=80 and "Length" not in t[0])
    for m in re.finditer(r"^\S+_RSVB_F\s+(\d+)\s+(\w{4})\s+([\d.]+)\s+\((\d)/9\)\s+(\S+)(.*)$",b,re.M):
        p,ctx,pot,j,res,rest=m.groups(); rec.append(dict(name=name,pos=int(p),ctx=ctx,pot=float(pot),jury=int(j),sequon="SEQUON" in rest))
d=pd.DataFrame(rec); print({k:len(v) for k,v in seqs.items()}, d.name.nunique())
isref=d.name.str.startswith("OP975389"); nb=d[~isref].name.nunique()
def seq(v): return {m.start()+1:m.group(0) for m in re.finditer(r"(?=(N[^P][ST]))",v)}
R=[k for k in seqs if k.startswith("OP975389")][0]; rs=seq(seqs[R]); print("ref sequons",rs)
B={k:v for k,v in seqs.items() if k!=R}; c=collections.Counter(p for v in B.values() for p in seq(v)); print(dict(c))
rows=[]
for p in sorted(set(rs)|set(c)):
    sub=d[(d.pos==p)&~isref&d.sequon]; rp=d[(d.pos==p)&isref&d.sequon].pot
    rows.append(dict(Position=p,Sequon=(rs.get(p) or [seq(v).get(p) for v in B.values() if p in seq(v)][0]),BD_isolates_with_sequon=c.get(p,0),BD_total=nb,BD_frequency=round(c.get(p,0)/nb,3),
      BD_mean_potential=round(sub.pot.mean(),3) if len(sub) else np.nan,BD_isolates_potential_gt0_5=int((sub.pot>.5).sum()),Reference_potential=round(rp.iat[0],3) if len(rp) else np.nan,In_reference=p in rs))
T=pd.DataFrame(rows); T["Status"]=np.where(T.In_reference&(T.BD_isolates_with_sequon>0),"Shared with reference",np.where(T.In_reference,"Reference-only (lost in BD)","BD-only (gained)"))
T.to_csv(OUT_+"Supplementary_Table_Fig10b_N-glyc_RSVB_F.csv",index=False); print(T.to_string()); pickle.dump((T,nb),open(TMP_+"nb_T.pkl","wb"))
# whole-protein differences
print(sum(1 for v in B.values() if v!=seqs[R]),"differ from ref")
