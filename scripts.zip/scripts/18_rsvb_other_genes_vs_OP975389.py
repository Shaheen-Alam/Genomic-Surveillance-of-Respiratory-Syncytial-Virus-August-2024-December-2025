"""RSV-B non-F/G genes vs OP975389.1.
The MIRA report lists RSV-B changes against KF640637. Each isolate protein is rebuilt as
KF640637 protein + MIRA substitutions, then compared with the OP975389.1 GenBank protein
(coordinates = OP975389.1). Ambiguous calls (X, '.', '~') are unknown and are not counted."""
import re, sys, collections, openpyxl, csv, os
from Bio import SeqIO, Align
from Bio.Align import substitution_matrices
R="data/refs/"; OUT="output/tables/"
GENES=["NS1","NS2","N","P","M","SH","M2-1","M2-2","L"]
def prots(f):
    d={}
    for ft in SeqIO.read(f,"genbank").features:
        if ft.type!="CDS": continue
        g=ft.qualifiers["gene"][0]; pr=ft.qualifiers["product"][0]
        if g=="M2": g="M2-2" if "M2-2" in pr else "M2-1"
        d[g]=ft.qualifiers["translation"][0]
    return d
kf=prots(R+"KF640637.gb"); op=prots(R+"OP975389.1.gb")
# OP975389.1 annotates M with a 22-aa N-terminal extension; use the canonical start (METYVNK...)
i=op["M"].index("METYVNK"); op_m_offset=i; op["M"]=op["M"][i:]
al=Align.PairwiseAligner(); al.mode="global"; al.substitution_matrix=substitution_matrices.load("BLOSUM62")
al.open_gap_score=-6; al.extend_gap_score=-0.5
wb=openpyxl.load_workbook("data/MIRA_variant_report_Data_1.xlsx",read_only=True)
rows=[r for r in list(wb.active.iter_rows(values_only=True))[1:] if r[1]=="KF640637" and r[2] in GENES]
samples=sorted({r[0] for r in rows}); N=len(samples)
calls=[]; unknown=collections.defaultdict(list); problems=[]
for g in GENES:
    aln=al.align(kf[g],op[g])[0]
    kf2op={}
    for (a0,a1),(b0,b1) in zip(*aln.aligned):
        for k in range(a1-a0): kf2op[a0+k]=b0+k
    if len(kf2op)!=len(kf[g]) or len(kf[g])!=len(op[g]): problems.append((g,"length/indel",len(kf[g]),len(op[g])))
    for s in samples:
        r=[x for x in rows if x[0]==s and x[2]==g][0]
        seq=list(kf[g]); unk=set()
        for t in [x for x in (r[4] or "").split(", ") if x]:
            m=re.fullmatch(r"([A-Z])(\d+)([A-Z])",t)
            if m:
                f,p,a=m.group(1),int(m.group(2)),m.group(3)
                if seq[p-1]!=f: problems.append((g,s,t,"ref residue is",seq[p-1]))
                if a=="X": unk.add(p-1)
                else: seq[p-1]=a
                continue
            m=re.fullmatch(r"([A-Z])(\d+)[.~]",t)
            if m: unk.add(int(m.group(2))-1); continue
            problems.append((g,s,t,"unparsed"))
        for p in sorted(unk): unknown[(g,s)].append(p+1)
        for i0,j in kf2op.items():
            if i0 in unk: continue
            if seq[i0]!=op[g][j]:
                calls.append((g,j+1,op[g][j],seq[i0],s))
print("samples",samples); print("problems",problems)
agg=collections.defaultdict(list)
for g,p,r,a,s in calls: agg[(g,p,r,a)].append(s)
order={g:i for i,g in enumerate(GENES)}
with open(OUT+"RSVB_other_genes_vs_OP975389.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["Gene","Position","Mutation","n","N_known","Sample_IDs"])
    for (g,p,r,a),ss in sorted(agg.items(),key=lambda x:(order[x[0][0]],x[0][1])):
        known=N-sum(1 for s in samples if p in unknown.get((g,s),[]))
        w.writerow([g,p,f"{r}{p}{a}",len(ss),known,"; ".join(x.split("_")[0] for x in sorted(ss))])
with open(OUT+"RSVB_other_genes_ambiguous_positions.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["Gene","Sample","Ambiguous_positions"])
    for (g,s),ps in sorted(unknown.items()): w.writerow([g,s,",".join(map(str,ps))])
print(len(agg),"unique;",len(calls),"events")
for k,v in sorted(agg.items(),key=lambda x:(order[x[0][0]],x[0][1])): print(k,len(v))
