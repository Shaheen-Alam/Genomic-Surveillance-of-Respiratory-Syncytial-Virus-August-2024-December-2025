"""Compare candidate reference proteins: mean number of amino-acid differences per Bangladeshi isolate (F and G).
Candidates: RSV-A  KY654518.1 (MIRA reference, ON1), PP109421.1 (Nextclade reference), NC_001803.1 (A2 prototype)
            RSV-B  OP975389.1 (Nextclade reference), KF640637.1 (MIRA reference)
Isolate proteins: data/*_MIRA_proteins_with_ref.fasta (first record = reference, skipped).
Writes output/tables/Reference_comparison_protein_level.csv (Supplementary Table S31)."""
import statistics as st, pandas as pd
from Bio.Align import PairwiseAligner, substitution_matrices
from common import DATA, OUT
al = PairwiseAligner(); al.mode = "global"; al.substitution_matrix = substitution_matrices.load("BLOSUM62")
al.open_gap_score = -6; al.extend_gap_score = -.5
def rd(p):
    r = []
    for l in open(p):
        l = l.strip()
        if l.startswith(">"): r.append([l[1:], ""])
        elif l: r[-1][1] += "".join(l.split())
    return [q.rstrip("*") for _, q in r]
def diffs(ref, q):
    a = al.align(ref, q)[0]; rs, qs = a.aligned
    m = sum(1 for (r0, r1), (q0, q1) in zip(rs, qs) for k in range(r1 - r0) if ref[r0 + k] != q[q0 + k] and q[q0 + k] != "X")
    gaps = (len(ref) - sum(r1 - r0 for r0, r1 in rs)) + (len(q) - sum(q1 - q0 for q0, q1 in qs))
    return m, gaps
REFS = {"RSV-A": [("KY654518.1 (MIRA)", "KY654518.1_RSVA_{p}.fasta"), ("PP109421.1 (Nextclade)", "PP109421.1_RSVA_{p}.fasta"), ("NC_001803.1 (A2 prototype)", "NC_001803.1_RSVA_{p}.fasta")],
        "RSV-B": [("OP975389.1 (Nextclade)", "OP975389.1_RSVB_{p}.fasta"), ("KF640637.1 (MIRA)", "KF640637.1_RSVB_{p}.fasta")]}
rows = []
for lin, cands in REFS.items():
    for p in "FG":
        iso = rd(DATA / f"{p}_{'RSVA' if lin=='RSV-A' else 'RSVB'}_MIRA_proteins_with_ref.fasta")[1:]
        for name, fn in cands:
            ref = rd(DATA / "refs" / fn.format(p=p))[0]
            res = [diffs(ref, q) for q in iso]
            rows.append(dict(Lineage=lin, Protein=p, Reference=name, Ref_length=len(ref), N_isolates=len(iso),
                             Mean_differences=round(st.mean(m for m, g in res), 1), Min=min(m for m, g in res), Max=max(m for m, g in res),
                             Mean_gap_residues=round(st.mean(g for m, g in res), 1)))
T = pd.DataFrame(rows); (OUT / "tables").mkdir(exist_ok=True); T.to_csv(OUT / "tables" / "Reference_comparison_protein_level.csv", index=False); print(T.to_string(index=False))
