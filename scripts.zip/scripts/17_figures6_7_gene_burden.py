"""Figures 6 (RSV-A) and 7 (RSV-B): number of amino acid changes per gene in every isolate, from output/tables/Mutations_by_gene_S2_S20.csv.
RSV-B changes in genes other than F and G: MIRA protein calls rebuilt against OP975389.1 (script 18)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import OUT_
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
o = pd.read_csv(OUT_ + "tables/Mutations_by_gene_S2_S20.csv", dtype={"Sample_IDs": str}).fillna("")
os.makedirs(OUT_ + "figures", exist_ok=True)
for lin, code, genes, fig in (("RSV-A", "A", ["F", "G", "L", "M", "M2-1", "M2-2", "N", "NS1", "NS2", "P", "SH"], 6), ("RSV-B", "B", ["F", "G", "L", "M2-1", "M2-2", "N", "NS2", "P"], 7)):
    d = o[o.Lineage == lin]; ids = sorted({i for s in d.Sample_IDs for i in s.split("; ") if i}, reverse=True)
    if lin == "RSV-A": assert len(ids) == 43
    M = pd.DataFrame(0, index=ids, columns=genes); un = 0
    for r in d.itertuples():
        L = [i for i in r.Sample_IDs.split("; ") if i]; un += r.n - len(L)
        for i in L: M.loc[i, r.Gene] += 1
    if un: print(f"{lin}: {un} change events without a sample assignment are not drawn")
    lab = [f"hRSV{code}/Bangladesh/ICDDRB-{i}/20{i[1:3]}" for i in M.index]
    h = max(3.5, 0.17 * len(M) + 1.6); f, ax = plt.subplots(figsize=(8.2, h))
    A = M.values.astype(float); A[A == 0] = np.nan
    im = ax.imshow(A, aspect="auto", cmap="plasma_r", vmin=1, vmax=max(A[~np.isnan(A)].max(), 2), interpolation="nearest")
    ax.set_xticks(range(len(genes))); ax.set_xticklabels(genes, fontsize=8); ax.set_yticks(range(len(M))); ax.set_yticklabels(lab, fontsize=6.5 if len(M) > 10 else 9)
    for y in range(A.shape[0]):
        for x in range(A.shape[1]):
            if not np.isnan(A[y, x]) and len(M) <= 10: ax.text(x, y, int(A[y, x]), ha="center", va="center", fontsize=8, color="white" if A[y, x] < A[~np.isnan(A)].max() * .6 else "black")
    ax.set_xlabel("Gene"); ax.set_ylabel("Sequence"); ax.set_title(f"Gene-wise amino acid changes per isolate ({lin}; reference {'KY654518.1' if code == 'A' else 'OP975389.1'})", fontsize=9)
    for s in ax.spines.values(): s.set_visible(False)
    cb = f.colorbar(im, ax=ax, fraction=0.04, pad=0.02); cb.set_label("Changes per gene", fontsize=8); cb.ax.tick_params(labelsize=7)
    f.tight_layout(); f.savefig(OUT_ + f"figures/Figure{fig}_gene_burden.png", dpi=300); f.savefig(OUT_ + f"figures/Figure{fig}_gene_burden.pdf"); f.savefig(OUT_ + f"figures/Figure{fig}_gene_burden.svg"); plt.close(f)
    M.to_csv(OUT_ + f"tables/Gene_burden_per_isolate_{code}.csv"); print(lin, "figure written; per-isolate total min/max", int(M.sum(axis=1).min()), int(M.sum(axis=1).max()))
