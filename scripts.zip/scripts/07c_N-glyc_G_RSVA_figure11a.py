import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import pickle, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
T=pickle.load(open(TMP_+"nG_T.pkl","rb")); nb=43  # number of Bangladeshi RSV-A isolates
T["x"]=T.Position_BD.fillna(T.Reference_position)
dom=[("TM",38,66,"#bdbdbd"),("MLR-I",67,163,"#1B9E77"),("CCD",164,181,"#D62728"),("CX3C",182,186,"#E6B800"),("HBD",187,198,"#1F77B4"),("MLR-II",199,321,"#B39DDB")]
fig,(ax,bx)=plt.subplots(2,1,figsize=(10,5.4),dpi=300,sharex=True,gridspec_kw=dict(height_ratios=[6,.8],hspace=.06))
S=T[T.n>0]
for _,r in S.iterrows():
    c="#2C7FB8" if r.mean_pot>=.5 else "#888888"
    ax.vlines(r.x,0,r.mean_pot,color=c,lw=1.8); ax.scatter(r.x,r.mean_pot,s=40+160*r.freq,color=c,zorder=3)
ax.scatter(T.x[T.ref_pot.notna()&(T.n>0)],T.ref_pot[T.ref_pot.notna()&(T.n>0)],marker="D",s=60,facecolors="none",edgecolors="#222",lw=1,zorder=4)
L=T[T.n==0]
ax.scatter(L.x,[0.02]*len(L),marker="^",s=70,facecolors="white",edgecolors="#444",lw=1.3,zorder=4)
for _,r in T.iterrows():
    nm=int(r.Reference_position) if r.n==0 else int(r.Position_BD)
    top=(max(r.mean_pot,r.ref_pot if r.ref_pot==r.ref_pot else 0) if r.n>0 else .02)
    if nm==251: continue
    dx=0
    ax.text(r.x+dx+(.5 if nm==250 else 0),top+.07,(f"N250/N251\n(0/{nb})" if nm==250 else f"N{nm}\n({int(r.n)}/{nb})"),fontsize=8.5,fontweight="bold",ha="center",va="bottom")
ax.axhline(.5,ls="--",color="grey",lw=1); ax.text(4,.51,"NetNGlyc threshold (0.5)",ha="left",fontsize=8.5,color="grey")
ax.set_ylim(0,1.0);ax.set_ylabel("NetNGlyc 1.0 potential");ax.set_title("N-glycosylation sequons of the RSV-A G protein",loc="left",fontweight="bold",pad=8)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
for nm,a,b,c in dom:
    bx.barh(0,b-a+1,left=a,height=.8,color=c,alpha=.9); bx.text((a+b)/2,0,nm if b-a>10 else "",ha="center",va="center",fontsize=8,fontweight="bold",color="white" if nm in("MLR-I","CCD","HBD") else "#222")
bx.text(184,.62,"CX3C",ha="center",fontsize=7.5,va="bottom")
bx.set_ylim(-.6,.95);bx.set_yticks([]);bx.set_xlim(0,330);bx.set_xlabel("Amino acid position (RSV-A G protein, Bangladeshi isolate numbering)")
for sp in ("top","right","left"): bx.spines[sp].set_visible(False)
h=[Line2D([],[],marker="o",ls="",color="#2C7FB8"),Line2D([],[],marker="o",ls="",color="#888"),Line2D([],[],marker="D",ls="",mfc="none",mec="#222")]
fig.legend(h,["Sequon, potential ≥ 0.5","Sequon, potential < 0.5","Reference KY654518.1"],loc="lower center",ncol=3,frameon=False,fontsize=8.5)
fig.subplots_adjust(bottom=.2,top=.92,left=.08,right=.98)
plt.savefig(OUT_+"Figure11a_simplified.png");plt.savefig(OUT_+"Figure11a_simplified.pdf")
