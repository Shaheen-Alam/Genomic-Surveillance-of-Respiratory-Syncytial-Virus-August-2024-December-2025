import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import re, pandas as pd, numpy as np, collections
txt=pdftext("NetNGlyc_G_RSVA.pdf")
blocks=re.split(r"^\s*Output for ",txt,flags=re.M)[1:]
seqs={};rec=[]
for b in blocks:
    m=re.search(r"^\s*Name:\s+(\S+)\s+Length:\s+(\d+)",b,re.M); name=m.group(1)
    s="".join(t[0] for t in (l.split() for l in b.split("\n")) if len(t)==2 and t[1].isdigit() and re.fullmatch(r"[A-Z\*]+",t[0]) and len(t[0])<=80 and "Length" not in t[0]); seqs[name]=s
    for m in re.finditer(r"^\s*(?:\S+_RSVA_G|KY654518\.1_G_Protein)\s+(\d+)\s+(\w{4})\s+([\d.]+)\s+\((\d)/9\)\s+(\S+)(.*)$",b,re.M):
        p,ctx,pot,j,res,rest=m.groups(); rec.append(dict(name=name,pos=int(p),ctx=ctx,pot=float(pot),jury=int(j),sequon=("SEQUON" in rest) or bool(re.match(r"N[^P][ST]",ctx))))
d=pd.DataFrame(rec); print({k:len(v) for k,v in list(seqs.items())[:3]}, d.name.nunique(), d.sequon.mean())
d.to_pickle(TMP_+"nG.pkl"); import pickle; pickle.dump(seqs,open(TMP_+"nGseq.pkl","wb"))
ref=seqs["KY654518.1_G_Protein"]; print(ref[:30])
from Bio import Align
al=Align.PairwiseAligner(); al.mode="global"; al.open_gap_score=-6; al.extend_gap_score=-.5
from Bio.Align import substitution_matrices; al.substitution_matrix=substitution_matrices.load("BLOSUM62")
first=[k for k in seqs if k!="KY654518.1_G_Protein"][0]; a=al.align(ref,seqs[first])[0]; print("example alignment (",first,"):",a.aligned)
