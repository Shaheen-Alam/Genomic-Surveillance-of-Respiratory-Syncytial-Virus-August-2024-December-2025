import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import re, pandas as pd, numpy as np
txt=pdftext("NetNGlyc_F_RSVA.pdf")
rec=[]
for m in re.finditer(r"^\s*(\S+_RSVA_F|KY654518\.1_F_protein)\s+(\d+)\s+(\w{4})\s+([\d.]+)\s+\((\d)/9\)\s+(\S+)(.*)$",txt,re.M):
    n,p,ctx,pot,j,res,rest=m.groups()
    rec.append(dict(name=n,pos=int(p),ctx=ctx,pot=float(pot),jury=int(j),res=res,sequon=("SEQUON" in rest) or bool(re.match(r"N[^P][ST]",ctx))))
d=pd.DataFrame(rec); print(d.name.nunique(), len(d), d.sequon.mean())
d["pos_site"]=d.pot>0.5
isref=d.name.str.startswith("KY654518"); nb=d[~isref].name.nunique(); print(nb)
print(d[isref&d.sequon][["pos","ctx","pot","jury","res"]])
S=d[d.sequon&(d.pot>.5)]
g=S[~S.name.str.startswith("KY654518")].groupby("pos").agg(n=("name","size"),mean=("pot","mean"),ctx=("ctx",lambda x:"/".join(sorted(set(x)))))
print(g.assign(freq=g.n/nb).round(3).to_string())
# non-sequon positives
print(d[(d.pot>.5)&~d.sequon&~isref].groupby("pos").size().sort_values(ascending=False).head(8))
d.to_pickle(TMP_+"nF.pkl")
