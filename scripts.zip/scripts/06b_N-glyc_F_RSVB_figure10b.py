import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import pickle, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
T,nb=pickle.load(open(TMP_+"nb_T.pkl","rb"))
ag=[("Ø",61,69,"#E41A1C"),("V",160,180,"#377EB8"),("Ø",196,212,"#E41A1C"),("II",254,277,"#4DAF4A"),("I",382,396,"#984EA3"),("IV",422,438,"#FF7F00")]
fig,(ax,bx)=plt.subplots(2,1,figsize=(10,5.4),dpi=300,sharex=True,gridspec_kw=dict(height_ratios=[6,.7],hspace=.06))
for nm,a,b,c in ag: ax.axvspan(a,b,color=c,alpha=.12,lw=0); bx.barh(0,b-a+1,left=a,height=.8,color=c,alpha=.85); bx.text((a+b)/2,.75,nm,ha="center",fontsize=8,fontweight="bold",color=c)
for _,r in T.iterrows():
    c="#2C7FB8" if r.BD_mean_potential>=.5 else "#888888"
    ax.vlines(r.Position,0,r.BD_mean_potential,color=c,lw=1.8); ax.scatter(r.Position,r.BD_mean_potential,s=40+160*r.BD_frequency,color=c,zorder=3)
ax.scatter(T.Position,T.Reference_potential,marker="D",s=60,facecolors="none",edgecolors="#222",lw=1,zorder=4)
ax.axhline(.5,ls="--",color="grey",lw=1); ax.text(4,.51,"NetNGlyc threshold (0.5)",ha="left",fontsize=8.5,color="grey")
Tx=[ax.text(r.Position,r.BD_mean_potential+.05,f"N{r.Position}\n({r.BD_isolates_with_sequon}/{nb})",fontsize=8.5,fontweight="bold",ha="center") for _,r in T.iterrows()]
adjust_text(Tx,ax=ax,arrowprops=dict(arrowstyle="-",lw=.4,color="grey"),expand=(1.2,1.4))
ax.set_ylim(0,1.0);ax.set_ylabel("NetNGlyc 1.0 potential");ax.set_title("N-glycosylation sequons of the RSV-B F protein",loc="left",fontweight="bold",pad=8)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
bx.set_ylim(-.6,1.2);bx.set_yticks([]);bx.set_xlim(0,580);bx.set_xlabel("Amino acid position (RSV-B F protein)")
for sp in ("top","right","left"): bx.spines[sp].set_visible(False)
h=[Line2D([],[],marker="o",ls="",color="#2C7FB8"),Line2D([],[],marker="o",ls="",color="#888"),Line2D([],[],marker="D",ls="",mfc="none",mec="#222")]
fig.legend(h,["Sequon, potential ≥ 0.5","Sequon, potential < 0.5","Reference OP975389"],loc="lower center",ncol=3,frameon=False,fontsize=8.5)
fig.subplots_adjust(bottom=.2,top=.92,left=.08,right=.98)
plt.savefig(OUT_+"Figure10b_simplified.png");plt.savefig(OUT_+"Figure10b_simplified.pdf")
