"""Amino acid changes per gene (Supplementary Tables S2-S20), relative to the chosen references.
RSV-A : KY654518.1.  F and G from the protein FASTA calls (output/tables/calls_*); the other nine genes from the MIRA variant
        report (data/MIRA_variant_report_Data_1.xlsx), which MIRA made against KY654518. Only residue-to-residue substitutions are
        counted; ambiguous residues (X), deletions (.) and other symbols are not counted as substitutions and are tallied separately.
RSV-B : OP975389.1.  F and G from the protein FASTA calls. The other genes: MIRA reported RSV-B changes against KF640637, so
        script 18 rebuilds each isolate protein from KF640637 + MIRA substitutions and compares it with the OP975389.1 GenBank proteins.
Output: output/tables/Mutations_by_gene_S2_S20.csv ; output/tables/Mutations_by_gene_ambiguous.csv"""
import os, sys, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_
import pandas as pd
T = OUT_ + "tables/"
GENES_A = ["F", "G", "L", "M", "M2-1", "M2-2", "N", "NS1", "NS2", "P", "SH"]
GENES_B = ["F", "G", "L", "M2-1", "M2-2", "N", "NS2", "P"]
TAB = {("RSV-A", g): i + 2 for i, g in enumerate(GENES_A)}; TAB.update({("RSV-B", g): i + 13 for i, g in enumerate(GENES_B)})
def cls(p): return "Fixed" if p >= 100 else "Near-fixed" if p >= 90 else "Common" if p >= 50 else "Moderate" if p >= 10 else "Rare"
mira = pd.read_excel(DATA_ + "MIRA_variant_report_Data_1.xlsx"); mira["id"] = mira.Sample.str.split("_").str[0]
isoA = sorted(set(l[1:].split("_")[0] for l in open(DATA_ + "F_RSVA_MIRA_proteins_with_ref.fasta") if l.startswith(">")) - {"KY654518.1"})
isoB = sorted(set(l[1:].split("_")[0] for l in open(DATA_ + "F_RSVB_MIRA_proteins_with_ref.fasta") if l.startswith(">")) - {"OP975389"})
assert len(isoA) == 43 and len(isoB) == 6
out = []; amb = []
def add(lin, g, pos, ref, alt, ids, N, src, typ="sub"):
    n = len(ids); out.append(dict(Table=f"S{TAB[(lin, g)]}", Lineage=lin, Gene=g, Position=pos, Mutation=f"{ref}{pos}{alt}", Type=typ, n=n, N=N, Percent=round(100 * n / N, 1), Class=cls(100 * n / N), Source=src, Sample_IDs="; ".join(sorted(ids))))
# F and G, both lineages: protein calls (same calls that feed Supplementary Tables S23/S24 before merging)
for lin, key, iso, refname in (("RSV-A", "RSVA", isoA, "KY654518.1"), ("RSV-B", "RSVB", isoB, "OP975389.1")):
    for g in "FG":
        c = pd.read_csv(T + f"calls_{g}_{key}.csv", dtype={"isolate": str})
        for (pos, ref, alt, typ), grp in c.groupby(["ref_pos", "ref", "alt", "type"]):
            ids = sorted(set(grp.isolate))
            if "X" in alt: amb.append(dict(Lineage=lin, Gene=g, Position=pos, Call=f"{ref}{pos}{alt}", n=len(ids), Sample_IDs="; ".join(ids))); continue
            add(lin, g, pos, ref, alt, ids, len(iso), f"protein FASTA vs {refname}", typ)
# RSV-A other genes from the MIRA report
for g in GENES_A[2:]:
    sub = mira[(mira.Reference == "KY654518") & (mira.Protein == g) & mira.id.isin(isoA)]
    calls = {}; other = {}
    for r in sub.itertuples():
        for v in str(r._5).split(", "):
            if v in ("nan", ""): continue
            m = re.match(r"^([A-Z])(\d+)([A-Z])$", v)
            if m and m.group(3) != "X": calls.setdefault((int(m.group(2)), m.group(1), m.group(3)), set()).add(r.id)
            else: other.setdefault(v, set()).add(r.id)
    for (pos, ref, alt), ids in calls.items(): add("RSV-A", g, pos, ref, alt, ids, 43, "MIRA variant report vs KY654518")
    ambn = len({i for s in other.values() for i in s}); amb.append(dict(Lineage="RSV-A", Gene=g, Position="", Call=f"{len(other)} ambiguous/deleted positions (X, ., ~)", n=ambn, Sample_IDs=""))
# RSV-B other genes: MIRA protein changes converted to OP975389.1 coordinates (script 18)
sb = pd.read_csv(T + "RSVB_other_genes_vs_OP975389.csv", dtype={"Sample_IDs": str}).fillna("")
for r in sb.itertuples():
    m = re.match(r"^([A-Z])(\d+)([A-Z])$", r.Mutation); ids = [i for i in r.Sample_IDs.split("; ") if i]
    assert r.N_known == 6 and len(ids) == r.n
    out.append(dict(Table=f"S{TAB[('RSV-B', r.Gene)]}", Lineage="RSV-B", Gene=r.Gene, Position=int(m.group(2)), Mutation=r.Mutation, Type="sub", n=r.n, N=6, Percent=round(100 * r.n / 6, 1), Class=cls(100 * r.n / 6), Source="MIRA protein vs OP975389.1 (via KF640637 calls)", Sample_IDs="; ".join(sorted(ids))))
o = pd.DataFrame(out).sort_values(["Table", "Position", "Mutation"], key=lambda s: s if s.name != "Table" else s.str[1:].astype(int)).reset_index(drop=True)
o.to_csv(T + "Mutations_by_gene_S2_S20.csv", index=False); pd.DataFrame(amb).to_csv(T + "Mutations_by_gene_ambiguous.csv", index=False)
print(o.groupby(["Lineage", "Gene"]).agg(unique=("Mutation", "count"), events=("n", "sum")).to_string())
