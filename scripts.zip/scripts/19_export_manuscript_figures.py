"""Copy the regenerated figures to output/manuscript_figures_revised/ under the numbering of the REVISED manuscript.

Script and file names elsewhere in this repository keep the first-draft numbers. Mapping (first draft -> revised):
  Figure 8, 9            -> Figure 4, 5
  Figure 10a/b, 11a/b    -> Figure 6a/b, 7a/b      (simplified versions)
  Figure 12a/b, 13a/b    -> Figure 8a/b, 9a/b      (main versions)
  Supplementary Figures 9-14 are unchanged (complete versions)
  Figure 6, 7            -> Supplementary Figure 17, 18
Writes SVG, PDF and 300 dpi PNG (whichever exist) and an index CSV.
"""
import csv, shutil
from common import OUT
F = OUT / "figures"
MAP = [  # (revised name, source stem, folder)
    ("Figure4", "Figure8_main", F), ("Figure5", "Figure9_main", F),
    ("Figure6a", "Figure10a_simplified", OUT), ("Figure6b", "Figure10b_simplified", OUT),
    ("Figure7a", "Figure11a_simplified", OUT), ("Figure7b", "Figure11b_simplified", OUT),
    ("Figure8a", "Figure12a_main", OUT), ("Figure8b", "Figure12b_main", OUT),
    ("Figure9a", "Figure13a_main", OUT), ("Figure9b", "Figure13b_main", OUT),
    ("SuppFigure9", "Figure8_supplementary", F), ("SuppFigure10", "Figure9_supplementary", F),
    ("SuppFigure11", "Figure12a_supplementary", OUT), ("SuppFigure12", "Figure12b_supplementary", OUT),
    ("SuppFigure13", "Figure13a_supplementary", OUT), ("SuppFigure14", "Figure13b_supplementary", OUT),
    ("SuppFigure17", "Figure6_gene_burden", F), ("SuppFigure18", "Figure7_gene_burden", F),
]
dst = OUT / "manuscript_figures_revised"; dst.mkdir(exist_ok=True)
rows = []
for new, stem, folder in MAP:
    got = []
    for ext in ("svg", "pdf", "png"):
        s = folder / f"{stem}.{ext}"
        if s.exists():
            shutil.copy(s, dst / f"{new}.{ext}"); got.append(ext)
    missing = {"svg", "pdf", "png"} - set(got)
    if missing: raise SystemExit(f"{new}: missing {sorted(missing)} (source {stem})")
    rows.append((new, stem, "+".join(got)))
with open(dst / "FIGURE_INDEX.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["revised_name", "first_draft_name", "formats"]); w.writerows(rows)
print(len(rows), "figures exported to", dst)
