import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from adjustText import adjust_text
U=DATA_
rows=[l.rstrip("\n").split("\t") for l in open(U+"NetOGlyc_G_RSVA.txt") if not l.startswith("#")]
rows=[r for r in rows if len(r)>=6 and r[2]=="CARBOHYD"]
d=pd.DataFrame({"n":[r[0] for r in rows],"p":[int(r[3]) for r in rows],"s":[float(r[5]) for r in rows]})
isref=d.n.str.startswith("KY654518"); nb=d[~isref].n.nunique()
DUP=(10**6,10**6); SH=0                  # reference KY654518.1 is an ON1 genome with the same 321-aa G protein: numbering is identical, no segment needs to be excluded
bd=d[~isref&(d.s>.5)].groupby("p").s.agg(n="size",mean="mean")
ref=d[isref&(d.s>.5)].p.tolist(); refmap={r:r for r in ref}
refset=set(refmap.values())
P=sorted(set(bd.index)|refset); rec=[]
for p in P:
    n=int(bd.n.get(p,0)); inref=p in refset
    if DUP[0]<=p<=DUP[1]: st="ON1 duplicated segment"
    elif n>0 and inref: st="Shared with reference"
    elif n>0: st="BD-only"
    else: st="Reference-only (absent in BD)"
    rr=[k for k,v in refmap.items() if v==p]
    rec.append(dict(Position_BD_numbering=p,Reference_position=(rr[0] if rr else p),BD_isolates_positive=n,BD_total=nb,BD_frequency=round(n/nb,3),
        BD_mean_score=round(bd["mean"].get(p,np.nan),3),In_reference_positive=inref,Status=st))
T=pd.DataFrame(rec); T.to_csv(OUT_+"Supplementary_Table_Fig13a_O-glyc_RSVA_G.csv",index=False)
print(T.Status.value_counts()); print(T[T.Status.isin(["BD-only","Reference-only (absent in BD)"])|((T.BD_frequency<.9)&(T.BD_frequency>0))].to_string())
C={"Shared with reference":"#2C7FB8","BD-only":"#D95F02","Reference-only (absent in BD)":"#888","ON1 duplicated segment":"#7B68AE"}
dom=[("TM",38,66,"#bdbdbd"),("MLR-I",67,163,"#1B9E77"),("CCD",164,181,"#D62728"),("CX3C",182,186,"#E6B800"),("HBD",187,198,"#1F77B4"),("MLR-II",199,320,"#B39DDB")]
fig,(ax,bx)=plt.subplots(2,1,figsize=(11,5.8),dpi=300,sharex=True,gridspec_kw=dict(height_ratios=[6,.9],hspace=.06))
for st in ["Shared with reference","BD-only","ON1 duplicated segment"]:
    q=T[(T.Status==st)&(T.BD_isolates_positive>0)]
    ax.vlines(q.Position_BD_numbering,0,q.BD_frequency,color=C[st],lw=.9,alpha=.85)
    ax.scatter(q.Position_BD_numbering,q.BD_frequency,s=14+30*q.BD_frequency,color=C[st],zorder=3)
q=T[T.Status=="Reference-only (absent in BD)"]
ax.scatter(q.Position_BD_numbering,[0.015]*len(q),marker="^",s=55,facecolors="white",edgecolors="#444",lw=1.2,zorder=4)
L=T[((T.BD_frequency<.85)&(T.BD_frequency>=.1))|(T.Status=="Reference-only (absent in BD)")|((T.Status=="BD-only")&(T.BD_frequency>=.1)&(T.BD_frequency<.95))].copy()
L=L[~L.Status.eq("ON1 duplicated segment")]; print("labels:",L.Position_BD_numbering.tolist())
Tx=[ax.text(r.Position_BD_numbering,max(r.BD_frequency,.03)+.015,str(r.Position_BD_numbering),fontsize=9,fontweight="bold",color="#222") for r in L.itertuples()]
adjust_text(Tx,ax=ax,arrowprops=dict(arrowstyle="-",lw=.4,color="grey"),expand=(1.3,1.6))
ax.set_ylim(0,1.14);ax.set_yticks([0,.25,.5,.75,1]);ax.set_yticklabels(["0%","25%","50%","75%","100%"]);ax.set_ylabel("Isolates with predicted site (%)")
ax.set_title("O-glycosylation sites of the RSV-A G protein",loc="left",fontweight="bold",pad=8)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
for nm,a,b,c in dom:
    bx.barh(0,b-a+1,left=a,height=.8,color=c,alpha=.9); bx.text((a+b)/2,0,nm if b-a>10 else "",ha="center",va="center",fontsize=8,fontweight="bold",color="white" if nm in("MLR-I","CCD","HBD") else "#222")
bx.text(184,.62,"CX3C",ha="center",fontsize=7.5,va="bottom")
bx.set_ylim(-.6,.95);bx.set_yticks([]);bx.set_xlim(0,335);bx.set_xlabel("Amino acid position (RSV-A G protein, Bangladeshi isolate numbering)")
for sp in ("top","right","left"): bx.spines[sp].set_visible(False)
h=[Line2D([],[],marker="o",ls="",color=C["Shared with reference"]),Line2D([],[],marker="o",ls="",color=C["BD-only"]),Line2D([],[],marker="^",ls="",mfc="white",mec="#444",ms=7)]
fig.legend(h,["Shared with reference","Bangladeshi isolates only","Reference only (absent in BD)"],loc="lower center",ncol=3,frameon=False,fontsize=9)
fig.subplots_adjust(bottom=.2,top=.92,left=.07,right=.98)
plt.savefig(OUT_+"Figure13a_simplified.png");plt.savefig(OUT_+"Figure13a_simplified.pdf")
