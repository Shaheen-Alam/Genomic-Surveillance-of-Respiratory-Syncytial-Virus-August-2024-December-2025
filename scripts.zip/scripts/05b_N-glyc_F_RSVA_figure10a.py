import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import re, collections, pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
d=pd.read_pickle(TMP_+"nF.pkl"); isref=d.name.str.startswith("KY654518"); nb=d[~isref].name.nunique()
Sq=d[d.sequon]
bd=Sq[~Sq.name.str.startswith("KY654518")].groupby("pos").agg(n=("name","size"),mean=("pot","mean"),n_pos=("pot",lambda x:(x>.5).sum()))
ref=Sq[Sq.name.str.startswith("KY654518")].set_index("pos").pot
T=bd.join(ref.rename("ref"),how="outer"); T["n"]=T.n.fillna(0).astype(int); T["n_pos"]=T.n_pos.fillna(0).astype(int)
T["freq"]=T.n/nb; T["context"]=[d[(d.pos==p)&d.sequon].ctx.mode().iat[0] for p in T.index]
T["status"]=np.where(T.ref.notna()&(T.n>0),"Reference sequon, conserved",np.where(T.ref.isna(),"BD-only sequon (gained)","Reference sequon, lost"))
out=T.reset_index().rename(columns={"pos":"Position","n":"BD_isolates_with_sequon","n_pos":"BD_isolates_potential>0.5","mean":"BD_mean_potential","ref":"Reference_potential","freq":"BD_frequency","context":"Sequon"}).round(3)
out["BD_total"]=nb; out.to_csv(OUT_+"Supplementary_Table_Fig10a_N-glyc_RSVA_F.csv",index=False); print(out.to_string())
ag=[("Site Ø",61,69,"#E41A1C"),("Site V",160,180,"#377EB8"),("Site Ø",196,212,"#E41A1C"),("Site II",254,277,"#4DAF4A"),("Site I",382,396,"#984EA3"),("Site IV",422,438,"#FF7F00")]
fig,(ax,bx)=plt.subplots(2,1,figsize=(10,5.4),dpi=300,sharex=True,gridspec_kw=dict(height_ratios=[6,.7],hspace=.06))
for nm,a,b,c in ag: ax.axvspan(a,b,color=c,alpha=.12,lw=0); bx.barh(0,b-a+1,left=a,height=.8,color=c,alpha=.85); bx.text((a+b)/2,.75,nm.replace("Site ",""),ha="center",fontsize=8,fontweight="bold",color=c)
cons=T[(T.status=="Reference sequon, conserved")]; gain=T[T.status=="BD-only sequon (gained)"]
hi=cons[cons["mean"]>=.5]; lo=cons[cons["mean"]<.5]
for q,c in ((hi,"#2C7FB8"),(lo,"#888888")):
    ax.vlines(q.index,0,q["mean"],color=c,lw=1.6); ax.scatter(q.index,q["mean"],s=40+160*q.freq,color=c,zorder=3)
ax.vlines(gain.index,0,gain["mean"],color="#D95F02",lw=1.2); ax.scatter(gain.index,gain["mean"],s=40+160*gain.freq,color="#D95F02",zorder=3)
ax.scatter(ref.index,ref.values,marker="D",s=60,facecolors="none",edgecolors="#222",lw=1,zorder=4)
ax.axhline(.5,ls="--",color="grey",lw=1); ax.text(4,.51,"NetNGlyc threshold (0.5)",ha="left",fontsize=8.5,color="grey")
Tx=[]
for p,r in T.iterrows():
    y=r["mean"] if not np.isnan(r["mean"]) else r.ref
    Tx.append(ax.text(p,y+.04,f"N{p}\n({r.n}/{nb})",fontsize=8.5,fontweight="bold",ha="center"))
adjust_text(Tx,ax=ax,arrowprops=dict(arrowstyle="-",lw=.4,color="grey"),expand=(1.2,1.4))
ax.set_ylim(0,1.0);ax.set_ylabel("NetNGlyc 1.0 potential");ax.set_title("N-glycosylation sequons of the RSV-A F protein",loc="left",fontweight="bold",pad=8)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
bx.set_ylim(-.6,1.2);bx.set_yticks([]);bx.set_xlim(0,580);bx.set_xlabel("Amino acid position (RSV-A F protein)")
for sp in ("top","right","left"): bx.spines[sp].set_visible(False)
h=[Line2D([],[],marker="o",ls="",color="#2C7FB8"),Line2D([],[],marker="o",ls="",color="#888"),Line2D([],[],marker="o",ls="",color="#D95F02"),Line2D([],[],marker="D",ls="",mfc="none",mec="#222")]
fig.legend(h,["Conserved sequon, potential ≥ 0.5","Conserved sequon, potential < 0.5","Gained in Bangladeshi isolates","Reference KY654518.1"],loc="lower center",ncol=4,frameon=False,fontsize=8.5)
fig.subplots_adjust(bottom=.2,top=.92,left=.08,right=.98)
plt.savefig(OUT_+"Figure10a_simplified.png");plt.savefig(OUT_+"Figure10a_simplified.pdf")
