"""Sample IDs behind every count in Supplementary Tables S23-S30.
Writes output/tables/SampleIDs_*.csv (full lists). Every list is checked against the n of the corresponding table."""
import os, sys, re, csv, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, pdftext
import pandas as pd
T = OUT_ + "tables/"
def sid(name): return name.split("_")[0]
REFS = ("KY654518", "OP975389", "KF640637")
def isref(n): return n.startswith(REFS)

# ---- S23 / S24 : substitutions, from the per-isolate calls
rows = []
for key in ("F_RSVA", "F_RSVB", "G_RSVA", "G_RSVB"):
    prot, lin = key[0], "RSV-" + key[-1]
    calls = pd.read_csv(T + f"calls_{key}.csv", dtype={"isolate": str})
    summ = pd.read_csv(T + f"summary_{key}.csv")
    g = calls.groupby(["ref_pos", "ref", "alt", "type"]).isolate.apply(lambda s: sorted(set(s))).to_dict()
    for r in summ.itertuples():
        ids = g[(r.ref_pos, r.ref, r.alt, r.type)]
        assert len(ids) == r.n, (key, r)
        rows.append(dict(Protein=prot, Lineage=lin, Ref_position=r.ref_pos, Ref=r.ref, Alt=r.alt, Type=r.type, n=r.n, N=r.N, Percent=r.pct, Sample_IDs="; ".join(ids)))
pd.DataFrame(rows).to_csv(T + "SampleIDs_F_G_amino_acid_changes.csv", index=False)

# ---- N-glycosylation (S26, S27): NetNGlyc reports
def nglyc(pdf):
    txt = pdftext(pdf).replace("\x0c", ""); rec = []
    for b in re.split(r"^\s*Output for ", txt, flags=re.M)[1:]:
        for m in re.finditer(r"^\s*(\S+_RSV[AB]_[FG]|\S+_[FG]_[Pp]rotein)\s+(\d+)\s+(\w{4})\s+([\d.]+)\s+\((\d)/9\)", b, re.M):
            nm, p, ctx, pot, j = m.groups()
            if not isref(nm) and re.match(r"N[^P][ST]", ctx): rec.append((sid(nm), int(p), float(pot)))
    return pd.DataFrame(rec, columns=["id", "pos", "pot"])
out = []
for prot in "FG":
    for lin in ("RSVA", "RSVB"):
        d = nglyc(f"NetNGlyc_{prot}_{lin}.pdf")
        for p, g in d.groupby("pos"):
            out.append(dict(Protein=prot, Lineage="RSV-" + lin[-1], Position=p, n_sequon=g.id.nunique(), IDs_sequon="; ".join(sorted(g.id)),
                            n_pot_ge_0_5=int((g.pot >= 0.5).sum()), IDs_pot_ge_0_5="; ".join(sorted(g.id[g.pot >= 0.5]))))
pd.DataFrame(out).to_csv(T + "SampleIDs_S23_S24_N-glycosylation_sites.csv", index=False)

# ---- O-glycosylation (S28-S30): NetOGlyc outputs (score > 0.5) and residues differing from the reference (F)
def oglyc(fn):
    rec = []
    for l in open(DATA_ + fn):
        if l.startswith("#"): continue
        t = l.rstrip("\n").split("\t")
        if len(t) >= 6 and t[2] == "CARBOHYD" and not isref(t[0]): rec.append((sid(t[0]), int(t[3]), float(t[5])))
    return pd.DataFrame(rec, columns=["id", "pos", "s"])
out = []
for prot, lin, fn in (("F", "RSV-A", "NetOGlyc_F_RSVA.tvs.txt"), ("F", "RSV-B", "NetOGlyc_F_RSVB.tvs.txt"), ("G", "RSV-A", "NetOGlyc_G_RSVA.txt"), ("G", "RSV-B", "NetOGlyc_G_RSVB.txt")):
    d = oglyc(fn)
    for p, g in d[d.s > 0.5].groupby("pos"):
        out.append(dict(Protein=prot, Lineage=lin, Position=p, n_score_gt_0_5=g.id.nunique(), IDs_score_gt_0_5="; ".join(sorted(g.id))))
pd.DataFrame(out).to_csv(T + "SampleIDs_S25_S27_O-glycosylation_sites.csv", index=False)

# residues at each F position that differ from the reference (for S28), from the protein FASTA
def fasta(fn):
    s = {}; k = None
    for l in open(DATA_ + fn):
        l = l.strip()
        if l.startswith(">"): k = l[1:].split("|")[0]; s[k] = ""
        elif k: s[k] += l
    return {k: v.rstrip("*") for k, v in s.items()}
out = []
for lin, fn in (("RSV-A", "F_RSVA_proteins_with_ref.fasta"), ("RSV-B", "F_RSVB_proteins_with_ref.fasta")):
    s = fasta(fn); R = [k for k in s if isref(k)][0]; ref = s[R]
    for k, v in s.items():
        if k == R: continue
        assert len(v) == len(ref)
        for i, (a, b) in enumerate(zip(ref, v)):
            if a != b: out.append(dict(Lineage=lin, Position=i + 1, Ref=a, Isolate_residue=b, id=sid(k)))
pd.DataFrame(out).to_csv(T + "SampleIDs_S25_F_residues_differing_from_reference.csv", index=False)
print("sample-ID tables written")
