import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import re, pickle, pandas as pd, numpy as np, collections, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
from Bio import Align
from Bio.Align import substitution_matrices
seqs=pickle.load(open(TMP_+"nGseq.pkl","rb")); d=pd.read_pickle(TMP_+"nG.pkl")
ref=seqs["KY654518.1_G_Protein"]; B={k:v for k,v in seqs.items() if not k.startswith("KY654518")}; nb=len(B)
al=Align.PairwiseAligner(); al.mode="global"; al.open_gap_score=-6; al.extend_gap_score=-.5; al.substitution_matrix=substitution_matrices.load("BLOSUM62")
def seq(v): return {m.start()+1 for m in re.finditer(r"(?=N[^P][ST])",v)}
# map BD position -> ref position via alignment (None = inserted/duplicated)
def bd2ref(v):
    a=al.align(ref,v)[0]; m={}
    for (r0,r1),(b0,b1) in zip(*a.aligned):
        for i in range(r1-r0): m[b0+i+1]=r0+i+1
    return m
maps={k:bd2ref(v) for k,v in B.items()}
ins=collections.Counter(p for k,v in B.items() for p in range(1,len(v)+1) if p not in maps[k]); print("inserted BD positions:",min(ins) if ins else None,max(ins) if ins else None,len(ins))
refseq=seq(ref); print("ref sequons:",sorted(refseq))
# per BD isolate: sequons in BD numbering, mapped to ref numbering when possible
rows=[]
pot=d[~d.name.str.startswith("KY654518")].set_index(["name","pos"]).pot; rpot=d[d.name.str.startswith("KY654518")].set_index("pos").pot
agg=collections.defaultdict(lambda:dict(n=0,pots=[]))
for k,v in B.items():
    for p in seq(v):
        r=maps[k].get(p); key=("ref",r) if r else ("ins",p)
        agg[key]["n"]+=1; agg[key]["pots"].append(pot.get((k,p),np.nan)); agg[key].setdefault("bdpos",collections.Counter())[p]+=1
out=[]
for (kind,p),a in agg.items():
    bp=a["bdpos"].most_common(1)[0][0]
    out.append(dict(Position_BD=bp,Reference_position=p if kind=="ref" else np.nan,n=a["n"],mean_pot=np.nanmean(a["pots"]),kind=kind,in_ref=(p in refseq) if kind=="ref" else False))
for p in refseq:
    if ("ref",p) not in agg: out.append(dict(Position_BD=np.nan,Reference_position=p,n=0,mean_pot=np.nan,kind="ref",in_ref=True))
T=pd.DataFrame(out); T["ref_pot"]=T.Reference_position.map(rpot); T["freq"]=T.n/nb
def st(r):
    if r.in_ref and r.n>0: return "Shared with reference"
    if r.in_ref: return "Reference-only (lost in BD)"
    return "BD-only (gained)"
T["Status"]=T.apply(st,axis=1); T=T.sort_values(["Position_BD","Reference_position"]).reset_index(drop=True)
T["Sequon_potential_gt0.5_in_BD"]=[sum(1 for k,v in B.items() for p in seq(v) if (maps[k].get(p)==r.Reference_position if r.kind=="ref" and not np.isnan(r.Reference_position) else p==r.Position_BD) and pot.get((k,p),0)>.5) for r in T.itertuples()]
T.round(3).to_csv(OUT_+"Supplementary_Table_Fig11a_N-glyc_RSVA_G.csv",index=False); print(T.round(3).to_string())
pickle.dump(T,open(TMP_+"nG_T.pkl","wb"))
