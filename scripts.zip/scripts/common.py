"""Shared paths and helpers."""
import subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = ROOT / "output"
TMP = OUT / "intermediate"
OUT.mkdir(exist_ok=True); TMP.mkdir(exist_ok=True)
DATA_ = str(DATA) + "/"
OUT_ = str(OUT) + "/"
TMP_ = str(TMP) + "/"


def pdftext(name):
    """Text of a NetNGlyc PDF report (needs poppler's pdftotext, layout mode)."""
    return subprocess.run(["pdftotext", "-layout", str(DATA / name), "-"],
                          capture_output=True, text=True, check=True).stdout
