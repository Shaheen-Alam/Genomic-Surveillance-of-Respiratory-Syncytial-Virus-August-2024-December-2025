"""Shared paths and helpers."""
import subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = ROOT / "output"
TMP = OUT / "intermediate"
OUT.mkdir(exist_ok=True); TMP.mkdir(exist_ok=True)
DATA_ = str(DATA) + "/"
OUT_ = str(OUT) + "/"
TMP_ = str(TMP) + "/"


def pdftext(name):
    """Text of a NetNGlyc PDF report (needs poppler's pdftotext, layout mode)."""
    return subprocess.run(["pdftotext", "-layout", str(DATA / name), "-"],
                          capture_output=True, text=True, check=True).stdout


# --- figure export: every figure saved as PDF is also written as SVG; raster output is 300 dpi -----------
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["savefig.dpi"] = 300
from matplotlib.figure import Figure as _Figure
_orig_savefig = _Figure.savefig


def _savefig(self, fname, *a, **k):
    _orig_savefig(self, fname, *a, **k)
    if str(fname).lower().endswith(".pdf"):
        _orig_savefig(self, str(fname)[:-4] + ".svg", *a, **k)


_Figure.savefig = _savefig
