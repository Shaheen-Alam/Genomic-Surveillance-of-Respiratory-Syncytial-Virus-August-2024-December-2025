"""Key positions for Figures 8-13 with the number of isolates (n) out of the total (N).
Everything is recomputed from the raw inputs in data/ (FASTA, NetOGlyc .tvs/.txt, NetNGlyc PDFs
via the tables produced by scripts 05-08) so that the numbers can be checked against the figures."""
import csv, collections
import pandas as pd
from common import DATA_, OUT, OUT_
T = OUT / "tables"
def rd(path):
    r = []
    for l in open(path):
        l = l.strip()
        if l.startswith(">"): r.append([l[1:], ""])
        elif l: r[-1][1] += "".join(l.split())
    return r

def motif_counts(fa, refskip=True):
    """number of isolates whose protein sequence has an N-X-S/T (X != P) motif starting at each position (isolate numbering)"""
    seqs = [q.rstrip("*") for _, q in rd(DATA_ + fa)][1:]
    c = collections.Counter()
    for q in seqs:
        for i in range(len(q) - 2):
            if q[i] == "N" and q[i + 1] != "P" and q[i + 2] in "ST": c[i + 1] += 1
    return c, len(seqs)
MC = {k: motif_counts(f) for k, f in (("FA", "F_RSVA_MIRA_proteins_with_ref.fasta"), ("FB", "F_RSVB_MIRA_proteins_with_ref.fasta"),
                                       ("GA", "G_RSVA_MIRA_proteins_with_ref.fasta"), ("GB", "G_RSVB_MIRA_proteins_with_ref.fasta"))}
def seqnote(key, pos):
    c, n = MC[key]; return f"motif N-X-S/T present by sequence in {c.get(pos, 0)}/{n}"
rows = []
def add(fig, prot, lin, pos, what, n, N, note=""):
    rows.append(dict(Figure=fig, Protein=prot, Lineage=lin, Position=pos, Feature=what, n=n, N=N, Percent=round(100 * n / N, 1), Note=note))

# ---- Figures 8 and 9: substitutions labelled in the main figures (same rule as script 11)
SITES = [("site Ø", 61, 69), ("site Ø", 196, 212), ("site V", 160, 180), ("site II", 254, 277), ("site I", 382, 396), ("site IV", 422, 438)]
def sites_of(p): 
    s = [n for n, a, b in SITES if a <= p <= b]; return s[0] if s else ("p27" if 110 <= p <= 136 else "")
def region_G(p):
    for n, a, b in [("TM", 38, 66), ("MLR-I", 67, 163), ("CCD", 164, 181), ("CX3C", 182, 186), ("HBD", 187, 198), ("MLR-II", 199, 400)]:
        if a <= p <= b: return n
for fig, prot, lin, key in (("8", "F", "RSV-A", "F_RSVA"), ("8", "F", "RSV-B", "F_RSVB"), ("9", "G", "RSV-A", "G_RSVA"), ("9", "G", "RSV-B", "G_RSVB")):
    for r in csv.DictReader(open(T / f"summary_{key}.csv")):
        if r["type"] != "sub": continue
        p, n, N = int(r["ref_pos"]), int(r["n"]), int(r["N"]); f = n / N
        ambiguous = "X" in r["alt"]
        if prot == "F": keep = sites_of(p) in ("site Ø", "site V", "site II", "site I", "site IV") or 0.1 <= f < 1 or lin == "RSV-B"
        else: keep = 164 <= p <= 198 or f >= 0.5
        if keep or ambiguous:
            reg = sites_of(p) if prot == "F" else region_G(p)
            add(fig, prot, lin, p, f'{r["ref"]}{p}{r["alt"]}' + (f" [{reg}]" if reg else ""), n, N,
                "ambiguous residue (X) in the MIRA consensus; not plotted" if ambiguous else "")
# ---- Figures 10-11: N-glycosylation sequons (all sequons reported in the supplementary tables)
t = pd.read_csv(OUT_ + "Supplementary_Table_Fig10a_N-glyc_RSVA_F.csv")
for r in t.to_dict("records"): add("10a", "F", "RSV-A", int(r["Position"]), f"N-sequon {r['Sequon']}; NetNGlyc potential>0.5 in {r['BD_isolates_potential>0.5']}/{r['BD_total']}", int(r["BD_isolates_with_sequon"]), int(r["BD_total"]), r["status"] + "; " + seqnote("FA", int(r["Position"])))
t = pd.read_csv(OUT_ + "Supplementary_Table_Fig10b_N-glyc_RSVB_F.csv")
for r in t.itertuples(): add("10b", "F", "RSV-B", int(r.Position), "N-sequon", int(r.BD_isolates_with_sequon), int(r.BD_total), r.Status + "; " + seqnote("FB", int(r.Position)))
t = pd.read_csv(OUT_ + "Supplementary_Table_Fig11a_N-glyc_RSVA_G.csv")
for r in t.itertuples():
    pos = int(r.Position_BD) if pd.notna(r.Position_BD) else int(r.Reference_position)
    add("11a", "G", "RSV-A", pos, f"N-sequon (reference N{int(r.Reference_position)})", int(r.n), 43, r.Status + ("; isolate numbering; " + seqnote("GA", pos) if pd.notna(r.Position_BD) else "; reference numbering"))
t = pd.read_csv(OUT_ + "Supplementary_Table_Fig11b_N-glyc_RSVB_G.csv")
for r in t.itertuples(): add("11b", "G", "RSV-B", int(r.Position_BD), "N-sequon", int(r.n), 6, r.Status + "; " + seqnote("GB", int(r.Position_BD)))
# ---- Figure 12: O-glycosylation of F; n = isolates with a Ser/Thr there / isolates with score > 0.5
for fig, lin, tv, fa, refpat, labs in (("12a", "RSV-A", "NetOGlyc_F_RSVA.tvs.txt", "F_RSVA_proteins_with_ref.fasta", "KY654518", [99, 105, 182, 186, 238, 244, 245, 248, 276, 369, 522, 523]),
                                      ("12b", "RSV-B", "NetOGlyc_F_RSVB.tvs.txt", "F_RSVB_proteins_with_ref.fasta", "OP975389", [100, 118, 128, 130, 182, 186, 190, 211, 244, 380, 389])):
    g = [l.rstrip("\n").split("\t") for l in open(DATA_ + tv) if not l.startswith("#")]
    g = [x for x in g if len(x) >= 6 and x[2] == "CARBOHYD"]
    d = pd.DataFrame({"n": [x[0] for x in g], "p": [int(x[3]) for x in g], "s": [float(x[5]) for x in g]})
    isref = d.n.str.contains(refpat); N = d[~isref].n.nunique()
    seqs = rd(DATA_ + fa); R = seqs[0][1].rstrip("*"); B = [s.rstrip("*") for _, s in seqs[1:]]
    for p in labs:
        col = collections.Counter(s[p - 1] for s in B); nst = sum(v for a, v in col.items() if a in "ST")
        sc = d[~isref & (d.p == p)].s; nthr = int((sc > .5).sum())
        comp = ", ".join(f"{a}:{v}" for a, v in col.most_common())
        extra = f"mean NetOGlyc score {sc.mean():.2f}; score > 0.5 in {nthr}/{N}" if len(sc) else f"no NetOGlyc score (no Ser/Thr)"
        add(fig, "F", lin, p, f"ref {R[p-1]}{p}; isolates {comp}", nst, N, f"n = isolates carrying Ser/Thr here; {extra}")
# ---- Figure 13: O-glycosylation of G (positions labelled in the main figures; rule as in script 09)
for fig, lin, csvn, P, N in (("13a", "RSV-A", "Supplementary_Table_Fig13a_O-glyc_RSVA_G.csv", "Position_BD_numbering", 43), ("13b", "RSV-B", "Supplementary_Table_Fig13b_O-glyc_RSVB_G.csv", "Position", 6)):
    t = pd.read_csv(OUT_ + csvn); ref_only = t.Status.str.startswith("Reference-only"); dup = t.Status.eq("ON1 duplicated segment")
    key = (~dup) & (ref_only | ((t.Status == "BD-only") & (t.BD_frequency >= .3)) | ((t.BD_frequency >= .3) & (t.BD_frequency < .7)) | t[P].between(164, 190))
    for r in t[key].itertuples():
        add(fig, "G", lin, int(getattr(r, P)), r.Status + (f"; in CCD/CX3C" if 164 <= getattr(r, P) <= 190 else ""), int(r.BD_isolates_positive), N, "isolate numbering" if lin == "RSV-A" else "")
out = pd.DataFrame(rows); out.to_csv(T / "Key_positions_n_over_N_Figures8-13.csv", index=False)
print(out.groupby("Figure").size())
