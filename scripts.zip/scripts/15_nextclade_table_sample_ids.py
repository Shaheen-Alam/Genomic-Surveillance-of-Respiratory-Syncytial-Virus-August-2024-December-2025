"""Sample IDs for the Nextclade-based mutation tables (Supplementary Tables S2-S20).
Rows are listed in data/Nextclade_tables_S2-S20_mutations.csv (mutation, n, N as printed in the supplement).
For each row the isolates are found, and accepted only if the number of isolates equals the n printed in the table:
  1 direct   : F and G only - protein compared with the Nextclade reference (PP109421.1 RSV-A, OP975389.1 RSV-B)
  2 mira     : isolates with the same change in the MIRA variant report (MIRA references KY654518 / KF640637)
  3 mira_rev : isolates WITHOUT the reverse change in the MIRA report (the MIRA reference already carries the Nextclade-reference-difference)
Rows that cannot be matched to the printed n are left blank (method 'unresolved') - never guessed."""
import os, sys, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_
import pandas as pd
def fasta(fn):
    s = {}; k = None
    for l in open(fn):
        l = l.strip()
        if l.startswith(">"): k = l[1:].split("|")[0]; s[k] = ""
        elif k: s[k] += l
    return s
mira = pd.read_excel(DATA_ + "MIRA_variant_report_Data_1.xlsx"); mira["id"] = mira.Sample.str.split("_").str[0]
ISO = {}; NCREF = {}; direct = {}
for lin, tag, ncf in (("RSV-A", "RSVA", "PP109421.1"), ("RSV-B", "RSVB", "OP975389.1")):
    ISO[lin] = sorted(k.split("_")[0] for k in fasta(DATA_ + f"F_{tag}_proteins_with_ref.fasta") if not k.startswith(("KY654518", "OP975389")))
    for prot in "FG":
        ref = "".join(fasta(DATA_ + f"refs/{ncf}_{tag}_{prot}.fasta").values())
        seqs = fasta(DATA_ + f"{prot}_{tag}_MIRA_proteins_with_ref.fasta")
        for k, v in seqs.items():
            if k.startswith(("KY654518", "OP975389")): continue
            v = v.rstrip("*"); calls = set()
            for i in range(min(len(ref), len(v))):
                if ref[i] != v[i] and v[i] != "X": calls.add(f"{ref[i]}{i+1}{v[i]}")
            direct[(lin, prot, k.split("_")[0])] = calls
rows = []
for r in pd.read_csv(DATA_ + "Nextclade_tables_S2-S20_mutations.csv").itertuples():
    ids = None; method = "unresolved"; n = int(r.n); allids = ISO[r.Lineage]; assert len(allids) == int(r.N)
    if r.Gene in ("F", "G"):
        h = [i for i in allids if r.Mutation in direct[(r.Lineage, r.Gene, i)]]
        if len(h) == n: ids, method = h, "direct"
    if ids is None:
        ref = "KY654518" if r.Lineage == "RSV-A" else "KF640637"
        sub = mira[(mira.Protein == r.Gene) & (mira.Reference == ref) & mira.id.isin(allids)]
        has = lambda m: set(x.id for x in sub.itertuples() if m in str(x._5).split(", "))
        h = sorted(has(r.Mutation))
        if len(h) == n: ids, method = h, "mira"
        else:
            m = re.match(r"^([A-Z*])(\d+)([A-Z*])$", r.Mutation)
            rev = has(f"{m.group(3)}{m.group(2)}{m.group(1)}") if m else set()
            h = sorted(set(allids) - rev)
            if rev and len(h) == n: ids, method = h, "mira_rev"
            elif n == len(allids): ids, method = list(allids), "all isolates (n = N)"
    rows.append(dict(Table=r.Table, Lineage=r.Lineage, Gene=r.Gene, Mutation=r.Mutation, n=n, N=int(r.N), Method=method, Sample_IDs="; ".join(ids) if ids else ""))
o = pd.DataFrame(rows); o.to_csv(OUT_ + "tables/SampleIDs_S2_S20_Nextclade_mutations.csv", index=False)
print(o.Method.value_counts().to_string()); print(o[o.Method == "unresolved"][["Table", "Gene", "Mutation", "n", "N"]].to_string())
