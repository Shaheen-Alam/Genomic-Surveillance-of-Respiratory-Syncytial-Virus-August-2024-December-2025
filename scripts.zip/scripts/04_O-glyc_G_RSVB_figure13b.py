import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
U=DATA_
rows=[l.rstrip("\n").split("\t") for l in open(U+"NetOGlyc_G_RSVB.txt") if not l.startswith("#")]
rows=[r for r in rows if len(r)>=6 and r[2]=="CARBOHYD"]
d=pd.DataFrame({"n":[r[0] for r in rows],"p":[int(r[3]) for r in rows],"s":[float(r[5]) for r in rows]})
isref=d.n.str.startswith("OP975389"); nb=d[~isref].n.nunique()
bd=d[~isref&(d.s>.5)].groupby("p").s.agg(n="size",mean="mean"); refp=set(d[isref&(d.s>.5)].p)
refs=d[isref].set_index("p").s
rec=[]
for p in sorted(set(bd.index)|refp):
    n=int(bd.n.get(p,0)); inref=p in refp
    st="Shared with reference" if n>0 and inref else "BD-only" if n>0 else "Reference-only (absent in BD)"
    rec.append(dict(Position=p,BD_isolates_positive=n,BD_total=nb,BD_frequency=round(n/nb,3),BD_mean_score_positive=round(bd["mean"].get(p,np.nan),3),
        Reference_score=round(refs.get(p,np.nan),3),In_reference_positive=inref,Status=st))
T=pd.DataFrame(rec); T.to_csv(OUT_+"Supplementary_Table_Fig13b_O-glyc_RSVB_G.csv",index=False)
print(nb,len(T)); print(T.Status.value_counts()); V=T[(T.Status!="Shared with reference")|(T.BD_frequency<1)]; print(V.to_string())
C={"Shared with reference":"#2C7FB8","BD-only":"#D95F02"}
dom=[("TM",38,66,"#bdbdbd"),("MLR-I",67,163,"#1B9E77"),("CCD",164,181,"#D62728"),("CX3C",182,186,"#E6B800"),("HBD",187,198,"#1F77B4"),("MLR-II",199,309,"#B39DDB")]
fig,(ax,bx)=plt.subplots(2,1,figsize=(11,5.8),dpi=300,sharex=True,gridspec_kw=dict(height_ratios=[6,.9],hspace=.06))
for st in C:
    q=T[(T.Status==st)]
    ax.vlines(q.Position,0,q.BD_frequency,color=C[st],lw=.9,alpha=.85)
    ax.scatter(q.Position,q.BD_frequency,s=14+30*q.BD_frequency,color=C[st],zorder=3)
q=T[T.Status=="Reference-only (absent in BD)"]
ax.scatter(q.Position,[0.02]*len(q),marker="^",s=55,facecolors="white",edgecolors="#444",lw=1.2,zorder=4)
L=T[((T.Status=="BD-only")&(T.BD_frequency>=.5))|(T.Status=="Reference-only (absent in BD)")|((T.BD_frequency>=.3)&(T.BD_frequency<.7))].copy()
print("labels:",L.Position.tolist())
Tx=[ax.text(r.Position,max(r.BD_frequency,.04)+.02,f"{r.Position} ({r.BD_isolates_positive}/{nb})" if r.Status!="Reference-only (absent in BD)" else f"{r.Position} (0/{nb})",fontsize=8.5,fontweight="bold",color="#222",ha="center") for r in L.itertuples()]
adjust_text(Tx,ax=ax,arrowprops=dict(arrowstyle="-",lw=.4,color="grey"),expand=(1.3,1.6))
ax.set_ylim(0,1.12);ax.set_yticks([0,.25,.5,.75,1]);ax.set_yticklabels(["0%","25%","50%","75%","100%"]);ax.set_ylabel("Isolates with predicted site (%)")
ax.set_title("O-glycosylation sites of the RSV-B G protein",loc="left",fontweight="bold",pad=8)
for sp in ("top","right"): ax.spines[sp].set_visible(False)
for nm,a,b,c in dom:
    bx.barh(0,b-a+1,left=a,height=.8,color=c,alpha=.9); bx.text((a+b)/2,0,nm if b-a>10 else "",ha="center",va="center",fontsize=8,fontweight="bold",color="white" if nm in("MLR-I","CCD","HBD") else "#222")
bx.text(184,.62,"CX3C",ha="center",fontsize=7.5,va="bottom")
bx.set_ylim(-.6,.95);bx.set_yticks([]);bx.set_xlim(0,318);bx.set_xlabel("Amino acid position (RSV-B G protein)")
for sp in ("top","right","left"): bx.spines[sp].set_visible(False)
h=[Line2D([],[],marker="o",ls="",color=C["Shared with reference"]),Line2D([],[],marker="o",ls="",color=C["BD-only"]),Line2D([],[],marker="^",ls="",mfc="white",mec="#444",ms=7)]
fig.legend(h,["Shared with reference","Bangladeshi isolates only","Reference only (absent in BD)"],loc="lower center",ncol=3,frameon=False,fontsize=9)
fig.subplots_adjust(bottom=.2,top=.92,left=.07,right=.98)
plt.savefig(OUT_+"Figure13b_simplified.png");plt.savefig(OUT_+"Figure13b_simplified.pdf")
