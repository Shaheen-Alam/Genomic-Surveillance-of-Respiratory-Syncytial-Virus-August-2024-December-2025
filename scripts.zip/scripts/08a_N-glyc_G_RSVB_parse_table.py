import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import re, pickle, pandas as pd, numpy as np, collections
from Bio import Align
from Bio.Align import substitution_matrices
txt=pdftext("NetNGlyc_G_RSVB.pdf").replace("\x0c","")
blocks=re.split(r"^Output for ",txt,flags=re.M)[1:]; seqs={};rec=[]
for b in blocks:
    m=re.search(r"^Name:\s+(\S+)\s+Length:\s+(\d+)",b,re.M); name=m.group(1)
    seqs[name]="".join(t[0] for t in (l.split() for l in b.split("\n")) if len(t)==2 and t[1].isdigit() and re.fullmatch(r"[A-Z\*]+",t[0]) and len(t[0])<=80 and "Length" not in t[0])
    for m in re.finditer(r"^\S+_RSVB_G\s+(\d+)\s+(\w{4})\s+([\d.]+)\s+\((\d)/9\)\s+(\S+)(.*)$",b,re.M):
        p,ctx,pot,j,res,rest=m.groups(); rec.append(dict(name=name,pos=int(p),ctx=ctx,pot=float(pot),sequon="SEQUON" in rest))
d=pd.DataFrame(rec); print({k:len(v) for k,v in seqs.items()}, d.name.nunique())
R=[k for k in seqs if k.startswith("OP975389")][0]; ref=seqs[R]; B={k:v for k,v in seqs.items() if k!=R}; nb=len(B)
al=Align.PairwiseAligner(); al.mode="global"; al.open_gap_score=-6; al.extend_gap_score=-.5; al.substitution_matrix=substitution_matrices.load("BLOSUM62")
def seq(v): return {m.start()+1 for m in re.finditer(r"(?=N[^P][ST])",v)}
def bd2ref(v):
    a=al.align(ref,v)[0]; m={}
    for (r0,r1),(b0,b1) in zip(*a.aligned):
        for i in range(r1-r0): m[b0+i+1]=r0+i+1
    return m
maps={k:bd2ref(v) for k,v in B.items()}
print("ref sequons:",sorted(seq(ref))); print({k:sorted(seq(v)) for k,v in B.items()})
print("unaligned BD positions:",{k:[p for p in range(1,len(v)+1) if p not in maps[k]] for k,v in B.items()})
pot=d[d.name!=R].set_index(["name","pos"]).pot; rpot=d[d.name==R].set_index("pos").pot
refseq=seq(ref); agg=collections.defaultdict(lambda:dict(n=0,pots=[],bd=collections.Counter(),n5=0))
for k,v in B.items():
    for p in seq(v):
        r=maps[k].get(p); key=("ref",r) if r else ("ins",p); a=agg[key]; a["n"]+=1; a["pots"].append(pot.get((k,p),np.nan)); a["bd"][p]+=1; a["n5"]+=int(pot.get((k,p),0)>.5)
out=[]
for (kind,p),a in agg.items():
    out.append(dict(Position_BD=a["bd"].most_common(1)[0][0],Reference_position=p if kind=="ref" else np.nan,n=a["n"],mean_pot=np.nanmean(a["pots"]),n_gt05=a["n5"],in_ref=(p in refseq) if kind=="ref" else False))
for p in refseq:
    if ("ref",p) not in agg: out.append(dict(Position_BD=np.nan,Reference_position=p,n=0,mean_pot=np.nan,n_gt05=0,in_ref=True))
T=pd.DataFrame(out); T["ref_pot"]=T.Reference_position.map(rpot); T["freq"]=T.n/nb
T["Status"]=np.where(T.in_ref&(T.n>0),"Shared with reference",np.where(T.in_ref,"Reference-only (lost in BD)","BD-only (gained)"))
T=T.sort_values(["Position_BD","Reference_position"]).reset_index(drop=True)
T.round(3).to_csv(OUT_+"Supplementary_Table_Fig11b_N-glyc_RSVB_G.csv",index=False); print(T.round(3).to_string())
pickle.dump((T,nb),open(TMP_+"ngb_T.pkl","wb"))
