import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import DATA_, OUT_, TMP_, pdftext
import sys, collections, pandas as pd, numpy as np
U=DATA_
CFG={"A":dict(tvs="NetOGlyc_F_RSVA.tvs.txt",fa="F_RSVA_proteins_with_ref.fasta",refpat="KY654518",refid="KY654518.1_RSVA"),
     "B":dict(tvs="NetOGlyc_F_RSVB.tvs.txt",fa="F_RSVB_proteins_with_ref.fasta",refpat="OP975389",refid="OP975389_RSVB")}
AG=[("Site Ø",61,69),("Site V",160,180),("Site Ø",196,212),("Site II",254,277),("Site I",382,396),("Site IV",422,438)]
def region(p):
    r="Signal peptide" if p<=25 else "F2" if p<=109 else "p27" if p<=136 else "F1"
    a=[n for n,s,e in AG if s<=p<=e]
    return r+(" ("+a[0]+")" if a else "")
for k,c in CFG.items():
    rows=[l.rstrip("\n").split("\t") for l in open(U+c["tvs"]) if not l.startswith("#")]
    rows=[r for r in rows if len(r)>=6 and r[2]=="CARBOHYD"]
    d=pd.DataFrame({"n":[r[0] for r in rows],"p":[int(r[3]) for r in rows],"s":[float(r[5]) for r in rows]})
    isref=d.n.str.contains(c["refpat"]); nb=d[~isref].n.nunique()
    ref=d[isref].set_index("p").s; bd=d[~isref].groupby("p").s.agg(["mean","std","count"])
    s={};kk=None
    for l in open(U+c["fa"]):
        l=l.strip()
        if l.startswith(">"): kk=l[1:].split("|")[0];s[kk]=""
        elif kk: s[kk]+=l
    s={a:v.rstrip("*") for a,v in s.items()}; R=s[c["refid"]]; B=[v for a,v in s.items() if a!=c["refid"]]
    out=[]
    for i,r in enumerate(R):
        p=i+1; col=collections.Counter(v[i] for v in B); nst=sum(x for a,x in col.items() if a in "ST")
        if r in "ST" or nst:
            res=", ".join(f"{a}:{n}" for a,n in col.most_common())
            st="Conserved Ser/Thr" if (r in "ST" and nst>0) else ("Ser/Thr lost in BD" if nst==0 else "Ser/Thr gained in BD")
            if r in "ST" and 0<nst<nb: st="Ser/Thr partly retained"
            m=bd["mean"].get(p,np.nan); sd=bd["std"].get(p,np.nan); rs=ref.get(p,np.nan)
            out.append(dict(Position=p,Ref_residue=r,BD_residues=res,BD_with_SerThr=nst,BD_total=nb,Status=st,Region=region(p),
              Ref_score=rs,BD_mean_score=m,BD_sd=sd,Delta=(m-rs) if pd.notna(m) and pd.notna(rs) else np.nan))
    df=pd.DataFrame(out).round(3); df.to_csv(f"{OUT_}Supplementary_Table_Fig12{k.lower()}_O-glyc_RSV{k}_F.csv",index=False); print(k,len(df)); print(df.Status.value_counts().to_dict())
