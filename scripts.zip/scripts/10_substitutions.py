"""Call amino-acid substitutions/indels of each isolate against the reference protein
(global alignment, BLOSUM62, gap open -6 / extend -0.5). Writes per-isolate calls and
per-position n/N summaries to output/tables/."""
import csv, collections
from Bio.Align import PairwiseAligner, substitution_matrices
from common import DATA, OUT
T = OUT / "tables"; T.mkdir(exist_ok=True)
SETS = {"F_RSVA": "F_RSVA_MIRA_proteins_with_ref.fasta", "F_RSVB": "F_RSVB_MIRA_proteins_with_ref.fasta",
        "G_RSVA": "G_RSVA_MIRA_proteins_with_ref.fasta", "G_RSVB": "G_RSVB_MIRA_proteins_with_ref.fasta"}
al = PairwiseAligner(); al.mode = "global"
al.substitution_matrix = substitution_matrices.load("BLOSUM62")
al.open_gap_score = -6; al.extend_gap_score = -0.5

def read_fasta(path):
    """Tolerant FASTA reader (the MIRA G files have indented, wrapped sequence lines)."""
    recs = []
    for line in open(path):
        line = line.strip()
        if line.startswith(">"): recs.append([line[1:], ""])
        elif line: recs[-1][1] += "".join(line.split())
    return [(h, q) for h, q in recs]

def call(ref, q):
    a = al.align(ref, q)[0]
    out = []  # (ref_pos, ref_aa, alt, type)
    rs, qs = a.aligned
    ri = qi = 0
    # walk the alignment block by block
    prev_r = prev_q = 0
    for (r0, r1), (q0, q1) in zip(rs, qs):
        if r0 > prev_r:   # deletion in query
            out.append((prev_r + 1, ref[prev_r:r0], "-", "del"))
        if q0 > prev_q:   # insertion in query (after ref pos r0)
            out.append((r0, "-", q[prev_q:q0], "ins"))
        for k in range(r1 - r0):
            if ref[r0 + k] != q[q0 + k]:
                out.append((r0 + k + 1, ref[r0 + k], q[q0 + k], "sub"))
        prev_r, prev_q = r1, q1
    if prev_r < len(ref): out.append((prev_r + 1, ref[prev_r:], "-", "del"))
    if prev_q < len(q): out.append((len(ref), "-", q[prev_q:], "ins"))
    return out

summary = {}
for name, fn in SETS.items():
    recs = read_fasta(DATA / fn)
    ref, iso = recs[0], recs[1:]
    R = ref[1].rstrip("*")
    rows = []
    for rid, seq in iso:
        q = seq.rstrip("*")
        tail = ""
        # C-terminal read-through (stop-loss): isolate is longer than the reference but identical in length up to the
        # reference end. The extra residues are reported as one "ext" event instead of letting the aligner guess.
        if len(q) > len(R) and sum(x == y for x, y in zip(R, q)) / len(R) > 0.9:
            q, tail = q[:len(R)], q[len(R):]
        for pos, a, b, t in call(R, q):
            rows.append((rid.split("_")[0], pos, a, b, t))
        if tail: rows.append((rid.split("_")[0], len(R) + 1, "*", tail, "ext"))
    with open(T / f"calls_{name}.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["isolate", "ref_pos", "ref", "alt", "type"]); w.writerows(rows)
    cnt = collections.Counter((p, a, b, t) for _, p, a, b, t in rows)
    with open(T / f"summary_{name}.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["ref_pos", "ref", "alt", "type", "n", "N", "pct"])
        for (p, a, b, t), n in sorted(cnt.items()):
            w.writerow([p, a, b, t, n, len(iso), round(100 * n / len(iso), 1)])
    summary[name] = (len(R), len(iso), len(cnt))
    print(name, "ref_len", len(R), "N", len(iso), "distinct changes", len(cnt))
