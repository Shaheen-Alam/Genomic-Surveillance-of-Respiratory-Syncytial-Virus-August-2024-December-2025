"""Figures 8 (F) and 9 (G): substitution maps vs the reference strain, RSV-A up / RSV-B down.
Main version labels only the positions discussed in the text; the supplementary version labels every change seen in >=10% of isolates (rarer changes are in the CSV tables).
Input: output/tables/summary_*.csv (from 10_substitutions.py)."""
import sys, csv
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from common import OUT
T = OUT / "tables"; F = OUT / "figures"; F.mkdir(exist_ok=True)
RED, BLUE = "#C0392B", "#2471A3"

def load(name):
    rows = []
    for r in csv.DictReader(open(T / f"summary_{name}.csv")):
        if r["type"] != "sub" or "X" in r["alt"]: continue      # ambiguous residues (X) are listed in the tables, not plotted
        rows.append(dict(pos=int(r["ref_pos"]), ref=r["ref"], alt=r["alt"], n=int(r["n"]), N=int(r["N"])))
    return rows

# antigenic sites (F) / functional regions (G)
SITES = [("Ø", 61, 69, "#F4D03F"), ("Ø", 196, 212, "#F4D03F"), ("V", 160, 180, "#58D68D"), ("II", 254, 277, "#EC7063"),
         ("I", 382, 396, "#85C1E9"), ("IV", 422, 438, "#BB8FCE")]
GREG = [("TM", 38, 66, "#BDBDBD"), ("MLR-I", 67, 163, "#1B9E77"), ("CCD", 164, 181, "#D62728"), ("CX3C", 182, 186, "#E6B800"),
        ("HBD", 187, 198, "#1F77B4"), ("MLR-II", 199, 330, "#B39DDB")]

def keep_F(r):   # discussed in text: any change in an antigenic site or p27, plus changes in >=10% but <100% of isolates
    ins = any(a <= r["pos"] <= b for _, a, b, _ in SITES)
    return ins or 0.10 <= r["n"] / r["N"] < 1
def keep_G(r):   # CCD-HBD (164-198) or present in 50-99% of isolates
    f = r["n"] / r["N"]
    return 164 <= r["pos"] <= 198 or f >= 0.5

def panel(ax, rows, sign, col, keep, full, xmax, nrows=3):
    keep = keep if keep else (lambda r: True)
    k = 0
    for r in sorted(rows, key=lambda r: r["pos"]):
        f = sign * r["n"] / r["N"]
        ax.vlines(r["pos"], 0, f, color=col, lw=1, alpha=.8)
        ax.scatter(r["pos"], f, s=12 + 30 * abs(f), color=col, zorder=3)
        if (full and (r["n"] / r["N"] >= 0.1)) or (not full and keep(r)):
            lab = f'{r["ref"]}{r["pos"]}{r["alt"]} ({r["n"]}/{r["N"]})'
            y = sign * (1.12 + 0.13 * (k % (6 if full else nrows))); k += 1   # labels sit in rows above the data, joined by a thin line
            ax.annotate(lab, (r["pos"], f), xytext=(r["pos"], y), ha="left" if r["pos"] < 25 else "center", va="bottom" if sign > 0 else "top",
                        fontsize=6.5 if full else 7.5, arrowprops=dict(arrowstyle="-", lw=.3, color="#999"))

def make(kind, full):
    if kind == "F":
        A, B, keep, xmax, title, band = load("F_RSVA"), load("F_RSVB"), keep_F, 574, "F protein", SITES
        nA, nB = 43, 6
    else:
        A, B, keep, xmax, title, band = load("G_RSVA"), load("G_RSVB"), keep_G, 322, "G protein", GREG
        nA, nB = 43, 6
    fig, (a1, ax, a2) = plt.subplots(3, 1, figsize=(13 if not full else 16, 7.2 if not full else 8.5), dpi=300, sharex=True,
                                     gridspec_kw=dict(height_ratios=[4, .7, 4], hspace=.08))
    panel(a1, A, +1, RED, keep, full, xmax); panel(a2, B, -1, BLUE, (keep_G if kind=="G" else None), full, xmax, nrows=(6 if kind=="F" else 5))
    a1.set_ylim(0, 1.6 if not full else 2.0); a2.set_ylim(-2.0 if (not full) else -2.0, 0)
    for a, s in ((a1, 1), (a2, -1)):
        a.set_yticks([s * v for v in (0, .5, 1)]); a.set_yticklabels(["0%", "50%", "100%"])
        a.set_ylabel("Isolates (%)"); [a.spines[k].set_visible(False) for k in ("top", "right")]
    a1.set_title(f"RSV-A {title} (n = {nA}), changes vs KY654518.1", loc="left", fontsize=10, fontweight="bold", color=RED)
    a2.text(0.005, 0.03, f"RSV-B {title} (n = {nB}), changes vs OP975389.1", transform=a2.transAxes, fontsize=10, fontweight="bold", color=BLUE)
    a1.tick_params(labelbottom=False); a1.spines["bottom"].set_visible(True)
    for nm, a, b, c in band:
        ax.barh(0, b - a + 1, left=a, height=.8, color=c, alpha=.9)
        if b - a >= 8: ax.text((a + b) / 2, 0, nm, ha="center", va="center", fontsize=8, fontweight="bold")
    if kind == "F":
        ax.barh(0, 27, left=110, height=.35, color="#555"); ax.text(123, -.62, "p27", ha="center", fontsize=7)
    ax.set_ylim(-.9, .9); ax.set_yticks([]); ax.set_xlim(0, xmax + 5)
    for k in ("top", "right", "left"): ax.spines[k].set_visible(False)
    ax.tick_params(labelbottom=False); a2.tick_params(labelbottom=True); a2.set_xlabel("Amino acid position (reference numbering)")
    out = f"Figure{8 if kind=='F' else 9}_{'supplementary' if full else 'main'}"
    fig.savefig(F / (out + ".png"), bbox_inches="tight"); fig.savefig(F / (out + ".pdf"), bbox_inches="tight"); fig.savefig(F / (out + ".svg"), bbox_inches="tight"); plt.close(fig)
    print("wrote", out)

for k in "FG":
    for full in (False, True): make(k, full)
