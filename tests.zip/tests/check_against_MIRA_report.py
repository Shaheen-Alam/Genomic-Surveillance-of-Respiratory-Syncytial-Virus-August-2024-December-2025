"""Check that the F and G amino-acid variants called here equal the variants in the MIRA report (data/MIRA_variant_report_Data_1.xlsx),
using the references MIRA used (RSV-A KY654518.1, RSV-B KF640637.1). Only the 49 manuscript isolates are compared."""
import sys, pandas as pd
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
from common import DATA
from Bio.Align import PairwiseAligner, substitution_matrices
al = PairwiseAligner(); al.mode = "global"; al.substitution_matrix = substitution_matrices.load("BLOSUM62"); al.open_gap_score = -6; al.extend_gap_score = -.5
def rd(p):
    r = []
    for l in open(p):
        l = l.strip()
        if l.startswith(">"): r.append([l[1:].split("|")[0].split("_")[0], ""])
        elif l: r[-1][1] += "".join(l.split())
    return {h: q.rstrip("*") for h, q in r}
def call(ref, q):
    tail = ""
    if len(q) > len(ref): q, tail = q[:len(ref)], q[len(ref):]
    a = al.align(ref, q)[0]; out = set()
    for (r0, r1), (q0, q1) in zip(*a.aligned):
        for k in range(r1 - r0):
            if ref[r0 + k] != q[q0 + k]: out.add(f"{ref[r0+k]}{r0+k+1}{q[q0+k]}")
    if tail: out.add(f"*{len(ref)+1}{tail}")
    return out
rep = pd.read_excel(DATA / "MIRA_variant_report_Data_1.xlsx"); bad = n = 0
for prot in "FG":
    for lin, refname, fa in (("RSVA", "KY654518", f"{prot}_RSVA_MIRA_proteins_with_ref.fasta"), ("RSVB", "KF640637", f"alt_reference_sets/{prot}_RSVB_MIRA_proteins_with_ref_KF640637.fasta")):
        seqs = rd(DATA / fa); ref = [v for k, v in seqs.items() if k.startswith(refname)][0]
        sub = rep[(rep.Protein == prot) & rep.Sample.str.endswith(lin)]
        for r in sub.itertuples():
            iso = r.Sample.split("_")[0]
            if iso not in seqs: continue          # MIRA report also lists samples that are not in the manuscript
            mira = set() if pd.isna(r[5]) else {x.strip() for x in str(r[5]).split(",")}
            mine = call(ref, seqs[iso]); n += 1
            if mira != mine: bad += 1; print("DIFF", prot, iso, sorted(mira ^ mine))
print(f"{n} isolate-protein comparisons, {bad} differences"); sys.exit(1 if bad else 0)
