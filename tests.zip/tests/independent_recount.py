"""Independent check of the Figure 8/9 counts: plain column-by-column comparison, no alignment.
Valid for F (no indels), RSV-B G (positions up to 310), and RSV-A G outside the ON1 duplication
(positions <=260 direct; positions >=286 compared with isolate residue = ref position + 24, C-terminal residues excluded)."""
import csv, collections, sys
from pathlib import Path
R = Path(__file__).resolve().parent.parent
def rd(p):
    r = []
    for l in open(p):
        l = l.strip()
        if l.startswith(">"): r.append(["", ""])
        elif l: r[-1][1] += "".join(l.split())
    return [s.rstrip("*") for _, s in r]
bad = 0
for key, shift_after, shift in (("F_RSVA", None, 0), ("F_RSVB", None, 0), ("G_RSVB", None, 0), ("G_RSVA", None, 0)):
    seqs = rd(R / "data" / f"{key}_MIRA_proteins_with_ref.fasta"); ref, iso = seqs[0], seqs[1:]
    direct = collections.Counter()
    for q in iso:
        for i, a in enumerate(ref, 1):
            j = i if (shift_after is None or i <= 260) else (i + shift if i > shift_after else None)
            if j is None or j > len(q) or False: continue
            if q[j - 1] != a and q[j - 1] != "X": direct[(i, a, q[j - 1])] += 1
    tab = {}
    for r in csv.DictReader(open(R / "output" / "tables" / f"summary_{key}.csv")):
        if r["type"] == "sub" and "X" not in r["alt"]: tab[(int(r["ref_pos"]), r["ref"], r["alt"])] = int(r["n"])
    # compare on the positions the direct method can validly assess
    for k, n in direct.items():
        if tab.get(k) != n: bad += 1; print("MISMATCH", key, k, "direct", n, "alignment", tab.get(k))
    for k, n in tab.items():
        i = k[0]; valid = shift_after is None or i <= 260 or (i > shift_after and i < 297)
        if valid and direct.get(k) != n: bad += 1; print("MISMATCH", key, k, "alignment", n, "direct", direct.get(k))
    print(key, "direct distinct changes:", len(direct), "checked")
print("recount OK" if bad == 0 else f"{bad} mismatches"); sys.exit(1 if bad else 0)
