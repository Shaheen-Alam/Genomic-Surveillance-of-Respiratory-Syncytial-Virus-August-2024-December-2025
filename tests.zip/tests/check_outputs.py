"""Compare regenerated tables with the tables used in the manuscript (run after run_all.sh)."""
import pandas as pd, pathlib, sys
root = pathlib.Path(__file__).resolve().parent.parent
bad = 0
for f in sorted((root / "manuscript_tables").glob("*.csv")):
    g = root / "output" / f.name
    if not g.exists(): g = root / "output" / "tables" / f.name
    if not g.exists():
        print("MISSING", f.name); bad += 1; continue
    a, b = pd.read_csv(f), pd.read_csv(g)
    same = a.shape == b.shape and a.fillna(-999).equals(b.fillna(-999))
    print("OK  " if same else "DIFF", f.name); bad += (not same)
sys.exit(1 if bad else 0)
