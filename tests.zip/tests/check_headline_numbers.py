"""Asserts the headline totals quoted in the manuscript (run after run_all.sh steps 16-17)."""
import os, pandas as pd
O = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output", "tables")
m = pd.read_csv(os.path.join(O, "Mutations_by_gene_S2_S20.csv"), dtype={"Sample_IDs": str}).fillna("")
def tot(lin): d = m[m.Lineage == lin]; return len(d), int(d.n.sum())
exp = {"RSV-A": (175, 952), "RSV-B": (61, 174)}
for lin, e in exp.items(): assert tot(lin) == e, (lin, tot(lin), e)
g = m.groupby(["Lineage", "Gene"]).agg(u=("n", "size"), e=("n", "sum"))
for k, v in {("RSV-A", "G"): (67, 525), ("RSV-A", "L"): (47, 177), ("RSV-A", "F"): (16, 83), ("RSV-A", "M2-2"): (9, 54),
             ("RSV-B", "G"): (33, 91), ("RSV-B", "L"): (12, 27), ("RSV-B", "F"): (7, 22)}.items():
    assert (g.loc[k].u, g.loc[k].e) == v, (k, tuple(g.loc[k]), v)
for r in m.itertuples():                                   # every count is backed by that many sample IDs
    ids = [i for i in r.Sample_IDs.split("; ") if i]; assert len(ids) == r.n and len(set(ids)) == r.n, (r.Table, r.Mutation)
for code, (mean, lo, hi) in {"A": (22.1, 15, 32), "B": (29.0, 26, 32)}.items():
    s = pd.read_csv(os.path.join(O, f"Gene_burden_per_isolate_{code}.csv"), index_col=0).sum(axis=1)
    assert round(s.mean(), 1) == mean and s.min() == lo and s.max() == hi, (code, s.mean(), s.min(), s.max())
print("OK   headline numbers")
